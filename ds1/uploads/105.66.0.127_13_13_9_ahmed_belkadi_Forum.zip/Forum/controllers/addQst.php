<?php

    include("../models/db.php");
    if( isset( $_POST['ajouter'] ) ) :

        $qst = $_POST['qst'];
        if ( !empty( $qst  )  ) {
            addQst($qst);
            header("Location: ../views/home.php");

        }else{
            header("Location: ../views/home.php?error=1");
        }

    endif; 
    
?>
