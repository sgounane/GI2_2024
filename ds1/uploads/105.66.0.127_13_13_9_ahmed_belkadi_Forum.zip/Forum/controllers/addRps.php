<?php

    include("../models/db.php");
    if( isset( $_POST['ajouter'] ) ) :

        $rps = $_POST['rps'];
        if ( !empty( $rps  )  ) {
            addRps($rps,$_GET["idd"]);
            header("Location: ../views/question.php?idQ=".$_GET['idd']);

        }

    endif; 
    
?>
