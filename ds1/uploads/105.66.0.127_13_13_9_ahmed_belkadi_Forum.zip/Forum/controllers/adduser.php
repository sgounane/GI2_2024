

<?php 

include("../models/db.php");

if (isset($_POST['ajouter'])) { 


        if (!empty( $_POST['nom'] ) && !empty( $_POST['email']  ) && !empty( $_POST['pass'] ) ) {
            addUser( $_POST['nom'] , $_POST['email'] , password_hash($_POST['pass'], PASSWORD_DEFAULT) );
            header("location:../views/login.php");

        }else{

            header("Location: ../views/register.php?error=2");

        }
    }
?>

