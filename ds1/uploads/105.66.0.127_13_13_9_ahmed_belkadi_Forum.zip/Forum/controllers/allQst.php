<?php 
    header("Content-Type:application/json");
    if( $_SERVER['REQUEST_METHOD'] == "GET"  ){
        $conn = new PDO( 'mysql:host=localhost;dbname=forum' , 'root' , '' );
        $qst = null;
        if( isset( $_GET['id'] ) ) { 
            $qst = $conn->query( "SELECT  q.id , q.question , q.date , g.nom , g.email FROM questions as q , users as g WHERE g.id = q.user_id WHERE q.id =". $_GET["id"]  )
            ->fetchAll(PDO::FETCH_ASSOC);
        }else{
            $qst = $conn->query( "SELECT  q.id , q.question , q.date , g.nom , g.email FROM questions as q , users as g WHERE g.id = q.user_id" )
            ->fetchAll(PDO::FETCH_ASSOC);
         }
        echo json_encode( [ "data" => $qst ] );
        
    }

?>