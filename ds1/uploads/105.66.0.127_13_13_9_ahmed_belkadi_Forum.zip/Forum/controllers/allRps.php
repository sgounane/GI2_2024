<?php 
    header("Content-Type:application/json");
    if( $_SERVER['REQUEST_METHOD'] == "GET" && isset( $_GET['idQ']) ){
        $conn = new PDO( 'mysql:host=localhost;dbname=forum' , 'root' , '' );
        $rps = null;
        
        $rps = $conn->query( "SELECT r.date , r.reponse , q.question , u.nom , u.email 
                                    FROM reponses as r ,questions as q , users as u 
                                    WHERE u.id = r.user_id AND r.question_id = q.id AND question_id =".$_GET['idQ']  )
        ->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode( [ "data" => $rps ] );
        
    }

?>