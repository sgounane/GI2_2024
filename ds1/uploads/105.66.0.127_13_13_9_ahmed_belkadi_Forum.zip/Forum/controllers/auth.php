<?php
include("../models/db.php");

                    if( isset( $_POST['submit'] ) ) :
                        $pass = $_POST['pass'];
                        $email = $_POST['email'];

                        if ( !empty( $_POST['email']  ) && !empty( $_POST['pass'] ) ) {
                            $user = getUserByEmail( $_POST['email'] );

                            if ($user && password_verify($pass, $user["password"])) {
                                session_start();
                                $_SESSION["user"] = $user;
                                header("Location: ../views/home.php");
                            } else {
                                header("Location: ../views/login.php?error=1");
                            }
            
                        }else{
                
                            header("Location: ../views/login.php?error=2");
                
                        }


                    endif; 
                ?>
