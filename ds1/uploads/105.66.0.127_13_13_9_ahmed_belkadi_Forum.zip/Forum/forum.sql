-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : mer. 22 nov. 2023 à 13:11
-- Version du serveur : 10.4.28-MariaDB
-- Version de PHP : 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `forum`
--

-- --------------------------------------------------------

--
-- Structure de la table `questions`
--

CREATE TABLE `questions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `question` varchar(200) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `questions`
--

INSERT INTO `questions` (`id`, `user_id`, `question`, `date`) VALUES
(1, 11, 'aaaaaaaaaaaaaaaaaaaaaaa', '2023-11-21'),
(2, 10, 'bbbbbbbbbbbbbbbbbbbbbbbbbb', '2023-11-30'),
(3, 11, 'xxxxxxxxxxxxxxxxxx', '2023-11-30'),
(4, 9, 'bbbbbbbbbbbbbbbb', '2023-11-30'),
(5, 11, 'ahmed', '2023-11-01'),
(6, 10, 'mmmmmmmmmmmmmmm', '2023-11-05'),
(7, 8, 'vvvvvvvvvvvvvv', '2023-11-09'),
(8, 10, 'qqqqqqqqqqq', '2023-11-22'),
(9, 10, 'xxxxxxxxxxx', '2023-11-22'),
(10, 11, 'kskskskss', '2023-11-22'),
(11, 11, 'ttttttttttttt', '2023-11-22'),
(12, 13, 'ooooooooooo', '2023-11-22'),
(13, 13, 'ana ahmed', '2023-11-22'),
(14, 13, 'hhh', '2023-11-22'),
(15, 13, 'ana ahmed 2', '2023-11-22'),
(16, 16, 'ana ahmed 55', '2023-11-22'),
(17, 16, 'ana ahmed 777777', '2023-11-22'),
(18, 14, 'xxccccccccccccccccc', '2023-11-01');

-- --------------------------------------------------------

--
-- Structure de la table `reponses`
--

CREATE TABLE `reponses` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `reponse` varchar(200) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `reponses`
--

INSERT INTO `reponses` (`id`, `user_id`, `question_id`, `reponse`, `date`) VALUES
(1, 11, 1, 'ccccccccccccccccccccccccccc', '2023-11-01'),
(2, 10, 2, 'ddddddddddddddddddddddddddd', '2023-11-02'),
(3, 13, 7, 'llllllllllllllllllllllllllllll', '2023-11-22'),
(4, 13, 2, 'nnnnnnnnnnnnnnnnn', '2023-11-22'),
(5, 13, 5, 'ccccccccccccc', '2023-11-22'),
(6, 13, 9, 'nbnbnb', '2023-11-22'),
(7, 13, 9, 'hhhh', '2023-11-22'),
(8, 13, 7, 'nbnbnb', '2023-11-22'),
(9, 13, 5, 'ppppppppppppppppppdddddddddddddd', '0000-00-00'),
(13, 13, 3, 'popopopopo', '0000-00-00'),
(14, 13, 3, 'popopo', '2023-11-30'),
(15, 13, 3, 'hgffgdhhhhhhh', '2023-11-08'),
(16, 13, 3, 'rsesrsesrsesrse', '2023-11-01'),
(18, 15, 7, 'nbnbnb', '2023-11-22'),
(19, 16, 1, 'nbnbnb', '2023-11-22');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `nom` text NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `nom`, `email`, `password`) VALUES
(8, 'user2', 'yser2@gmail.com', '$2y$10$g5qbY0Jp2u0vQ5XCuJrqf.41jcgZZQeiOr6y/GEbsFkt1eBVo8t6.'),
(9, 'kkkkkkkkkkk', 'admin@gmail.com', '$2y$10$WzLhyzPzHyOc2q1MUdJiXO2CTi/MNpKu79ouWgHoSpTqwYhe8RP3S'),
(10, 'hhh', 'hhh@gmail.com', 'hhh'),
(11, 'mouad', 'admin@gmail.com', '$2y$10$g7xK/04vIpDrxQEPN2rNMO2ue8QoI.jI7fQ5aTRHex2FsnAwmMhdm'),
(12, 'sss', 'hhh@gmail.com', '555'),
(13, 'kkkkkkkkkkk', 'ali@example.com', '$2y$10$6Z9AU5dZuMHhr0SXGKSoheIbuG5JRyPoIvX6ykV4z0shJB216z.0G'),
(14, 'hamada', 'hamada@example.com', '$2y$10$GCud4ENCKRjKQj.q0TxaF.vN.ccQmmkOUo7RNi0RV3PsjD.neoZVy'),
(15, 'Harrisooo', 'Harrisooo@example.com', '$2y$10$DaqO3qRpSc4BNOj21yiELOSlY..riRdj/RqzlL5oyYZnoHJP/J9.e'),
(16, 'mohammed', 'mohammed@gmail.com', '$2y$10$4gmQWGfBgRz7SKhL/3vExODd7Thv9A.xSjzbYueOVA1I7rLKLI8U6');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Index pour la table `reponses`
--
ALTER TABLE `reponses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `question_id` (`question_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT pour la table `reponses`
--
ALTER TABLE `reponses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `questions`
--
ALTER TABLE `questions`
  ADD CONSTRAINT `questions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `reponses`
--
ALTER TABLE `reponses`
  ADD CONSTRAINT `reponses_ibfk_1` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `reponses_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
