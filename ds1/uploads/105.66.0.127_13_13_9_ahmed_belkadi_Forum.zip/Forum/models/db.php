<?php 
    
    
    function  addUser($nom,$email,$password){
        $conn = new PDO( 'mysql:host=localhost;dbname=forum' , 'root' , '' );
        $sqlStmt = $conn->prepare( "INSERT INTO users VALUES(null,?,?,?)");
        $sqlStmt->execute( [ $nom,$email,$password ] );
    }

    function getUserByEmail($email){
        $conn = new PDO( 'mysql:host=localhost;dbname=forum' , 'root' , '' );
        $sqlStmt = $conn->prepare( "SELECT * FROM users WHERE email = ?");
        $sqlStmt->execute( [ $email ] );

        return $user = $sqlStmt->fetch(PDO::FETCH_ASSOC);
        
    }
    
    function getQuetions($id = 0 ){
        $conn = new PDO( 'mysql:host=localhost;dbname=forum' , 'root' , '' );
        if( $id != 0){
            $questions = $conn->query( "SELECT  q.id , q.question , q.date , g.nom , g.email 
            FROM questions as q , users as g WHERE g.id = q.user_id AND q.id = $id
            ORDER BY q.id desc" )
            ->fetch(PDO::FETCH_ASSOC);
        }else{
            $questions = $conn->query( "SELECT  q.id , q.question , q.date , g.nom , g.email 
            FROM questions as q , users as g 
            WHERE g.id = q.user_id
            ORDER BY q.id desc" )
            ->fetchAll(PDO::FETCH_ASSOC);
        }
        return $questions;

    }


    
    function getReponses($idQst){
        $conn = new PDO( 'mysql:host=localhost;dbname=forum' , 'root' , '' );
        $reponses = $conn->query( "SELECT r.date , r.reponse , q.question , u.nom , u.email ,r.id
                                    FROM reponses as r ,questions as q , users as u 
                                    WHERE u.id = r.user_id AND r.question_id = q.id AND question_id =  $idQst
                                    ORDER BY r.id desc" )
        ->fetchAll(PDO::FETCH_ASSOC);
        return $reponses;

    }

    function addQst($qst){
        $conn = new PDO( 'mysql:host=localhost;dbname=forum' , 'root' , '' );
        session_start();
        $sqlStmt = $conn->prepare( "INSERT INTO questions VALUES(null,?,?,?)");
        $sqlStmt->execute( [ $_SESSION["user"]['id'],$qst, date('Y-m-d') ] );
    }
    function addRps($rps,$id){
        $conn = new PDO( 'mysql:host=localhost;dbname=forum' , 'root' , '' );
        // echo("<pre>");
        // print_r($_GET);
        // echo("</pre>");
        session_start();
        $sqlStmt = $conn->prepare( "INSERT INTO reponses VALUES(null,?,?,?,?)");
        $sqlStmt->execute( [ $_SESSION["user"]['id'],$id,$rps, date('Y-m-d') ] );
    }

?>