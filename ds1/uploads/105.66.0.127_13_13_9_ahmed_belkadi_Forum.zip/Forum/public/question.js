
const url = "http://localhost/forum/controllers/allQst.php"

const qstsElm = document.querySelector("#qsts");

setInterval( ()=>{

  fetch( url )
  .then(response => response.json())
  .then(data => afficherQsts(data.data))
  .catch(error => console.error('Error:', error));

} ,30000)

function afficherQsts(qsts){
    qstsElm.innerHTML = ""
    qsts.forEach( ( {id,question,date,nom,email} )=>{

        qstsElm.innerHTML += `         
        <div class="card w-100 border border-2 border-secondary rounded-5 p-5 w-50 mb-5 " style="width: 18rem;">
            <div class="card-body  ">
                <h5 class="card-title"> ${date} ${nom} ${email}  </h5>
                <p class="card-text  "> ${question} </p>
                <div class="w-100 " >
                    <a href="./question.php?id=${id}" class="  w-100  card-link">Reponses</a>
                </div>
            </div>
        </div>`
            } )
  
}