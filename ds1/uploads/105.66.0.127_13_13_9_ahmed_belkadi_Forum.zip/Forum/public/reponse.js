

const rpnsElm = document.querySelector("#rpns");
const idQst = document.querySelector("#idQst").innerHTML;
const url = `http://localhost/forum/controllers/allRps.php?idQ=${idQst}`
// console.log(idQst.innerHTML);



setInterval( ()=>{

  fetch( url )
  .then(response => response.json())
  .then(data => afficherRpns(data.data))
  .catch(error => console.error('Error:', error));

} ,15000)

function afficherRpns(rpns){
    console.log(rpns);
    rpnsElm.innerHTML = ""
    rpns.forEach( ( r )=>{
        // console.log(r.id);
        rpnsElm.innerHTML += `         
        <div class="card w-100 border border-2 border-secondary rounded-5 p-5 w-50 mb-5 " style="width: 18rem;">
            <div class="card-body  ">
                <h5 class="card-title"> ${r.date} ${r.nom} ${r.email}  </h5>
                <p class="card-text  "> ${r.reponse} </p>
            </div>
        </div>`
            } )
  
}