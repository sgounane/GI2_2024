<?php  session_start() ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" >
    <script src="../public/question.js" defer></script>

    <title></title>
</head>
<body>
    


    <div class="container my-3 pt-5">

        <div class=" mb-5 w-100 " >
            <a href="./login.php" class="  w-100  card-link">
                <?php if(isset($_SESSION['user'])){
                    echo("Logout");
                }else{
                    echo("Login");
                } ?>   
            </a>       
        </div>

        <?php if(isset($_SESSION['user'])) : ?>
            <div class="card w-100 border border-2 border-secondary rounded-5 p-5 w-50 mb-5 " style="width: 18rem;">
                <div class="card-body  ">
                    
                    <form action="../controllers/addQst.php" method="post">
                            <?php if (isset($_GET["error"]) && $_GET["error"] == 1   ) :?>
                                    <div class="alert alert-danger text-center" role="alert">
                                                    question vide !! 
                                    </div>   
                            <?php endif ?>
                            <div class="mb-3">
                            <input type="text" class=" border border-2 border-secondary rounded-5 form-control" name="qst" id="" aria-describedby="helpId" placeholder="votre question ...">            
                            </div>
                            <input type="submit" value="Envoyer" class="btn bg-primary w-100" name="ajouter" >     

                    </form>
                </div>
            </div>
        <?php endif ?>

        <div class="mb-2  d-flex justify-content-between    " >
                <div class="d-flex justify-content-around w-75 " > <h1 class=" text-center text-primary" >LISTE DES QUESTIONS</h1></div>
            </div>

        <div  id="qsts" class="border border-2 border-secondary rounded-5 p-5 " >

            <?php 
            include("../models/db.php");
            $questions = getQuetions();
            // echo"<pre>";
            //     print_r($_GET);
            // echo"</pre>";
            foreach( $questions as $q ): ?>
                <div class="card w-100 border border-2 border-secondary rounded-5 p-5 w-50 mb-5 " style="width: 18rem;">
                    <div class="card-body  ">
                        <h5 class="card-title"><?= $q["date"]." ". $q["nom"]." ". $q["email"]  ?></h5>
                        <p class="card-text  "><?= $q["question"] ?></p>
                        <div class="w-100 " >
                            <a href="./question.php?idQ=<?=$q["id"]?>" class="  w-100  card-link">Reponses</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>

            

        </div>


    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>