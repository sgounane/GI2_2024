
<?php 
    session_start();
    isset($_SESSION['user']) ?  header('location:../controllers/logout.php') : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" >
    <link rel="stylesheet" href="./style.css">
    <title>login </title>
</head>
<body>


    <div class="container  vh-100">

        <form method="post" action="../controllers/auth.php" class=" d-flex flex-column justify-content-center align-items-center vh-100">


        
            <div class="border border-2 border-secondary rounded-5 p-5 w-50">
            <?php
            if (isset($_GET["error"]) && ($_GET["error"] == 1 || $_GET["error"] == 2)  ) {
                
                if($_GET["error"] == 1 ){

                ?>
                <div class="alert alert-danger text-center" role="alert">
                    Email ou  password incorrect !! 
                </div>  
            
                <?php
                }else{
                ?>
                <div class="alert alert-danger text-center" role="alert">
                tous les champs sont requis !! 
                </div>  
            
                <?php
                    
                }
            }
            ?>
                <div class="mb-3  w-100 ">
                    <label  class="form-label">email</label>
                    <input type="text" class="form-control border border-2 border-secondary rounded-5"  aria-describedby="emailHelp" name="email" > 
                </div>
                <div class="mb-3 w-100">
                    <label  class="form-label" >password</label>
                    <input type="password" name="pass" class="form-control border border-2 border-secondary rounded-5" >
                </div>
                <button type="submit" class="btn bg-primary border border-2  rounded-5 w-100" name="submit" >Submit</button>
                <a href="./register.php" >not a member ? sign up now</a>
            </div>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>    
</body>
</html>