
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" >
    <!-- <link rel="stylesheet" href="../../style.css"> -->
    <title>ajouter user</title>
</head>
<body>

  

    <div class="container pt-4">
            <form method="post" action="../controllers/adduser.php" class="d-flex flex-column justify-content-center align-items-center vh-100" >
                <div class="border border-2 border-secondary rounded-5 p-5 w-50">

                <?php
                    if (isset($_GET["error"]) &&  $_GET["error"] == 2  ) {
                ?>
                    
                        <div class="alert alert-danger text-center" role="alert">
                            tous les champs sont requis !!   
                        </div>  

                <?php
                    }
                
                ?>

                        <div class="mb-3">
                            <label  class="form-label">nom</label>
                            <input type="text" class="form-control"  aria-describedby="emailHelp" name="nom" > 
                        </div>

                        <div class="mb-3">
                            <label  class="form-label" >email</label>
                            <input type="email" name="email" class="form-control" >
                        </div>



                        <div class="mb-3">
                            <label  class="form-label" >password</label>
                            <input type="password" name="pass" class="form-control" >
                        </div>



                        <input type="submit" value="register" class="btn bg-primary w-100" name="ajouter" >     

                </div>
            </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>