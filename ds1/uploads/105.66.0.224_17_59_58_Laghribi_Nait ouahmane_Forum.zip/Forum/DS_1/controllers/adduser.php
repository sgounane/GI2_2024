 <?php 
    
    include "../models/db.php";


    $nom= $_POST["name"];
    $email = $_POST["email"];
    $password_user= $_POST["password"];
    
    $nom = htmlspecialchars($nom);
    $email = htmlspecialchars($email);
    $hashedPassword = password_hash($password_user, PASSWORD_DEFAULT);
           
    adduser($nom,$email,$hashedPassword);
       
    
 
 
 ?>