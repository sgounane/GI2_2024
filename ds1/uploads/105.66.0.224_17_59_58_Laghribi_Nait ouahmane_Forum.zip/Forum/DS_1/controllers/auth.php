<?php

include "../models/db.php";


function authenticateUser($email, $password) {
    $conn = connectDB();

    try {
        $user = getUserByEmail($email);
       
        
        if ($user && password_verify($password, $user['password'])) {
            session_start();
            $_SESSION['user'] =array(
                'nom' => $user['nom'],
                'email' => $user['email']
            );

            
            header("Location: ../views/home.php");
            exit();
        } else {
            
            header("Location: login.php?error=invalid_credentials");
            exit();
        }
    } catch (PDOException $e) {
        echo "Erreur lors de l'authentification : " . $e->getMessage();
    }
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $email = $_POST['email'];
    $password_login = $_POST['password'];

   
    authenticateUser($email, $password_login);
}
?>
