<?php
$servername = "localhost";
$username = "root";
$dbname = "forum";
$password = "";

function connectDB() {
    global $servername, $dbname, $username, $password;
    try {
        $conn = new PDO("mysql:host=".$servername.";dbname=".$dbname, $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        echo "connect ";
        return $conn;
       
    } catch (PDOException $e) {
        die("Erreur de connexion à la base de données : " . $e->getMessage());
    }
}


function adduser($nom, $email, $password) {
    $conn = connectDB();

    try {
        $stmt = $conn->prepare("INSERT INTO Users (nom, email, password ) VALUES (:nom, :email, :password)");
        
        $stmt->bindParam(':nom', $nom);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':password', $password);

        
        $stmt->execute();

        echo "Utilisateur ajouté avec succès.";
    } catch (PDOException $e) {
        echo "Erreur lors de l'ajout de l'utilisateur : " . $e->getMessage();
    }


   
}


function getUserByEmail($email) {
    $conn = connectDB();
    
    try {
        $stmt = $conn->prepare("SELECT * FROM Users WHERE email = :email");
        $stmt->bindParam(':email', $email); 
        $stmt->execute(); 
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($result) {
            return($result);
       
        } else {
            echo "Aucun utilisateur trouvé pour cet e-mail";
        }
    } catch (PDOException $e) {
        echo "Erreur lors de la recherche de l'utilisateur : " . $e->getMessage();
    }
}

function getQuetions() {
    $conn = connectDB();
    
    try {
        $stmt = $conn->prepare("SELECT * FROM Questions");
        
        $stmt->execute(); 
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($result) {
            return($result);
       
        } else {
            echo "Aucun Question trouvé ";
        }
    } catch (PDOException $e) {
        echo "Erreur Question " . $e->getMessage();
    }

}

function  getReponses($question_id){

    $conn = connectDB();
    
    try {
        $stmt = $conn->prepare("SELECT * FROM Reponses WHERE question_id = :question_id");
        $stmt->bindParam(':question_id', $question_id); 
        $stmt->execute(); 
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($result) {
            return($result);
       
        } else {
            echo "Aucun Reponses trouvé pour cet e-mail";
        }
    } catch (PDOException $e) {
        echo "Erreur lors de la recherche de Reponses  : " . $e->getMessage();
    }

}



?>
