<?php
session_start();
include "../models/db.php";
$questions []= getQuetions();
print_r($questions) ;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>home</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body>
<main class="w-1/2 h-auto  mx-auto gap-10 flex flex-col gap-10"> 
        <div class="question border-2 border-black  ">
        <label for="large-input" class="block mb-2 text-sm font-medium text-black ">Large input</label>
        <input type="text" id="large-input" class="block w-full p-4 text-black border border-gray-300 rounded-lg bg-gray-50 sm:text-md focus:ring-blue-500 focus:border-blue-500 " placeholder="votre question ici">
        <button type="button" class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:bg-blue-600 dark:hover:bg-blue-700 focus:outline-none dark:focus:ring-blue-800">Default</button>    
    </div>
    <section class="border-2 border-black">
            <?php foreach($questions as  $value) { ?>
                <div>
                    <div class="flex gap-10">
                    <?php echo '<p>User ID: ' . $value['user_id'] . '</p>'; ?> 
                    <?php echo '<p>Date' . $value['date'] . '</p>'; ?> 
                    </div>
                    <div>
                        <input type="text" id="disabled-input-2" aria-label="disabled input 2" class="bg-gray-100 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 cursor-not-allowed dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-gray-400 dark:focus:ring-blue-500 dark:focus:border-blue-500" value="<?php echo $value['question']; ?>" disabled readonly>
                    </div>
                    <div>
                       <?php  echo '<a href="question.php?ID='.$value['user_id'].'">send</a>'; ?>
                    </div>
                </div>
            <?php } ?>
        </section>

</main>
</body>
</html>