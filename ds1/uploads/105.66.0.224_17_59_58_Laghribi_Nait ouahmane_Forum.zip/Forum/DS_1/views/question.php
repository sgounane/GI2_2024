<?php
session_start();
include "../models/db.php";
$id =$_GET["ID"];
$questions = getQuetions();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<section class="border-2 border-black">
            <?php foreach($questions as  $value) { if ($value['user_id']==$id) {?>
                <div>
                    <div class="flex gap-10">
                    <?php echo '<p>User ID: ' . $value['user_id'] . '</p>'; ?> 
                    <?php echo '<p>Date' . $value['date'] . '</p>'; ?> 
                    </div>
                    <div>
                        <input type="text" id="disabled-input-2" aria-label="disabled input 2" class="bg-gray-100 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 cursor-not-allowed dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-gray-400 dark:focus:ring-blue-500 dark:focus:border-blue-500" value="<?php echo $value['question']; ?>" disabled readonly>
                    </div>
                    <div>
                       <?php  echo '<a href="question.php?ID='.$value['user_id'].'">send</a>'; ?>
                    </div>
                </div>
            <?php }} ?>
        </section>
</body>
</html>