<?php
session_start();
include_once ("../models/db.php");


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nom = filter_input(INPUT_POST, 'nom', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
    $password = $_POST["password"];
    $passwordedentique = $_POST["passwordedentique"];

    if (!$nom || !$email || !$password || ($password !== $passwordedentique)) {
        echo "Invalid. Please recheck the forme.";
        exit();
    }

    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    adduser($nom,$email,$hashedPassword);
    exit();
}

?>