<?php
session_start ();
include_once ("../models/db.php");

if ($_SERVER["REQUEST_METHOD"]== "POST"){
    $email = $_POST["email"];
    $password = $_POST["password"];

    $user = getUsersByEmail($email);

    if ($user && password_verify($password ,$user->password)){
        $_SESSION["user"] = ["id" => $user->id,"nom" => $user->nom, "email" => $user->email];
        header("Location: ../views/home.php");
        exit ();
    }
    else {
        header("Location: ../views/login.php?error=1");
        exit ();
    }
}