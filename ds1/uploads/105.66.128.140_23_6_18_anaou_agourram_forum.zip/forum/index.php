<?php
session_start();

$path=$_SERVER["REQUEST_URI"];

$basedir="/forum/";

switch($path){
case $basedir ."/":
     header("Location:views/home.php");break;
case $basedir ."/login":
     header("Location:views/login.php");break;
case $basedir ."/registrement":
     header("Location:views/register.php");break;

default:{
    
    echo "NOT FOUND !!!!!!" ;
} 

}
?>