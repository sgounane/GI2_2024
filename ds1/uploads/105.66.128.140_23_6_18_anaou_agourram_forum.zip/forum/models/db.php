<?php 

function connect(){
    try {
        $db=new PDO('mysql:host=localhost;dbname=forum','root','');
        return $db;
    }
    catch(PDOException $e){
        echo $e->getMessage();
        die();
    }
}

$db=connect();

function adduser($nom,$email,$password){
    global $db;
    $req=$db->prepare("INSERT INTO users (nom , email ,password) VALUES (:nam, :emai ,:pass)");
    $req->execute(["nam"=>$nom,"emai"=>$email,"pass"=>$password]);
    return $req;  
}
function getUsersByEmail($email){
    global $db;
    $req=$db->prepare ("SELECT * FROM users WHERE email = :emai");
    $req->execute(["emai"=>$email]);
    $user=$req->fetch(PDO::FETCH_OBJ);
    return $user;
}

function getUsersByID($id){
    global $db;
    $req=$db->prepare ("SELECT email FROM users WHERE id = :id");
    $req->execute(["id"=>$id]);
    $user=$req->fetch(PDO::FETCH_OBJ);
    return $user;
}

function addQuestion($userId,$question,$date){
    global $db;
    $req=$db->prepare("INSERT INTO questions (user_id , question ,date) VALUES (:usId, :ques,:dat)");
    $req->execute(["usId"=>$userId,"ques"=>$question,"dat"=>$date]);
    return $req;  
}

function addReponse($userId,$question_id,$response,$date){
    global $db;
    $req=$db->prepare("INSERT INTO reponses (user_id , question_id, response ,date) VALUES (:usId, :ques_id,:resp,:dat)");
    $req->execute(["usId"=>$userId,"ques_id"=>$question_id,"resp"=>$response,"dat"=>$date]);
    return $req;  
}

function getQuetions(){
    global $db;
    $req=$db->prepare ("SELECT * FROM questions ORDER BY date DESC ");
    $req->execute();
    $quests=$req->fetchAll(PDO::FETCH_OBJ);
    return $quests;
}

function getReponses($question_id){
    global $db;
    $req=$db->prepare ("SELECT * FROM reponses WHERE question_id = :ques");
    $req->execute(["ques"=>$question_id]);
    $repons=$req->fetchAll(PDO::FETCH_OBJ);
    return $repons;
}

?>