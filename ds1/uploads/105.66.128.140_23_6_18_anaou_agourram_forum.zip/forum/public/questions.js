function getNewQuestions() {
    
    fetch('db.php?action=getQuestions') 
        .then(response => response.json())
        .then(newQuestions => {
           
            console.log('New questions:', newQuestions);
            
        })
        .catch(error => console.error('Error fetching new questions:', error));
}

setInterval(getNewQuestions, 30000);