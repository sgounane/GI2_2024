function getNewReponses() {

    fetch('db.php?action=getReponses') 
        .then(response => response.json())
        .then(newReponses => {
            console.log('New responses:', newReponses);
        })
        .catch(error => console.error('Error fetching new responses:', error));
}

setInterval(getNewReponses, 30000);
