<?php
include_once ("../models/db.php");
include_once("../controller/auth.php");
$questions=getQuetions();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <style>
        .question {
            text-align:center;
            padding-top:10px;
        }
        .col-md-6{
            margin:20px;
        }

    </style>
</head>
<body>
    <div class="login">
    <?php if (isset($_SESSION["user"])): ?>
        <form action="logout.php" method="post">
            <button type="submit" class="btn btn-primary">Logout</button>
        </form>
    <?php else :?>
        <a href="login.php" class="btn btn-primary">Login</a>
        <?php endif; ?>       
    </div>
<div class="question">
<?php if (isset($_SESSION["user"])): ?>
        <h3>Post a New Question :</h3><br>
        <form action="question.php" method="post">
            <div class="form-row" align="center">
                <div class="form-group col-md-6">
                <input type="text" class="form-control" name="question" placeholder="votre question"><br>
                <button type="submit" class="btn btn-primary">Envoyer</button>
            </div></div>
</form>
    <?php endif; ?>

    </div>
    <div class="card" align="center">
            <?php foreach($questions as $quest): ?>
        <div class="card-header">
                <?php echo getUsersByID($quest->user_id)->email;?>
        </div>
         <div class="card-body">
            <h5 class="card-title"><?php echo $quest->date?></h5>
            <p class="card-text"><?php echo $quest->question ; ?></p>
            <a href="question.php" class="btn btn-primary">Réponses</a>
         </div>
         <?php endforeach?>
    </div>




        </body>
</html>