<?php
session_start();
include_once ("../models/db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $newQuestion = $_POST["question"];
    $userId = $_SESSION["user"]["id"];

    if (!empty($newQuestion)) {
        $query = $db->prepare("INSERT INTO questions (user_id, question, date) VALUES (:user_id, :question, NOW())");
        $query->execute(["user_id" => $userId, "question" => $newQuestion,]);
        exit();
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>testeeee</title>
</head>
<body>
    <div class="card" align="center"><?php
    if (isset($_GET['question_id'])) {
    $questionId = $_GET['question_id'];

    $reponses = getReponses('1');

    $_SESSION['question_reponses'] = $reponses;
}
        foreach($reponses as $resp): ?>
            <div class="card-body">
                <h5 class="card-title"><?php echo $resp->date?></h5>
                <p class="card-text"><?php echo $resp->reponse ; ?></p>
            </div>
        <?php  endforeach?>
    </div> 
</body>
</html>
