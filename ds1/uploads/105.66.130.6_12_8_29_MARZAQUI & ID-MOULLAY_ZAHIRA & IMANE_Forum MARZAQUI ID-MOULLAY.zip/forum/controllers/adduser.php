<?php
// adduser.php

include('../models/db.php'); // Inclure le fichier db.php qui contient la connexion à la base de données

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Récupérer les données du formulaire
    $nom = $_POST['nom'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Appeler la fonction adduser pour insérer un nouvel utilisateur
    adduser($nom, $email, $password);

    // Rediriger ou effectuer d'autres actions après l'enregistrement
    header("Location: confirmation.php");
    exit();
}
?>
