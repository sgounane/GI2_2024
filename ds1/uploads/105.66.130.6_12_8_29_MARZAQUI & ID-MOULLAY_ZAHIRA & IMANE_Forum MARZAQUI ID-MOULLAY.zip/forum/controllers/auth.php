<?php
// auth.php

include('../models/db.php');

session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Récupérer les données du formulaire
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Récupérer les données de l'utilisateur depuis la base de données
    $user = getUserByEmail($email);
    var_dump($user);

    // Vérifier si l'utilisateur existe et le mot de passe est correct
    if ($user && password_verify($password, password_hash($password,PASSWORD_DEFAULT))){
        
        $_SESSION['user'] = array(
            'nom' => $user['nom'],
            'email' => $user['email']
        );
        
header("Location: ../views/home.php");
exit();
    } else {
        // Rediriger vers login avec un message d'erreur
        $_SESSION['erreur_login'] = "Adresse e-mail ou mot de passe incorrect";
        header("Location: ../views/login.php");
        echo 'not ok';
        exit();
    }
}
?>
