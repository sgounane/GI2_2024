<?php


$serveur = "localhost";
$utilisateur = "root";
$motDePasse = "";
$baseDeDonnees = "forum";

try {
    $bdd = new PDO("mysql:host=$serveur;dbname=$baseDeDonnees", $utilisateur, $motDePasse);
    $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Erreur de connexion à la base de données : " . $e->getMessage();
}

function adduser($nom, $email, $password) {
    global $bdd;

    $requete = $bdd->prepare("INSERT INTO users (nom, email, password) VALUES (:nom, :email, :password)");
    $requete->execute(array(
        'nom' => $nom,
        'email' => $email,
        'password' => password_hash($password, PASSWORD_DEFAULT)
    ));
}

    function getUserByEmail($email) {
        global $bdd;
    
        $requete = $bdd->prepare("SELECT * FROM users WHERE email = :email");
        $requete->execute(array('email' => $email));
    
        
        $user = $requete->fetch(PDO::FETCH_ASSOC);
    
        return $user; 
    }
   
   
    
    function insertQuestion($user_id, $question) {
        global $bdd;
    
        $requete = $bdd->prepare("INSERT INTO questions (user_id, question) VALUES (:user_id, :question)");
        $requete->execute(array('user_id' => $user_id, 'question' => $question));
    }
    
    
    function getQuestions() {
        global $bdd;
    
        $requete = $bdd->query("SELECT * FROM questions");
        $questions = $requete->fetchAll(PDO::FETCH_ASSOC);
    
        return $questions;
    }



function getReponses($question_id) {
    global $bdd;

    $requete = $bdd->prepare("SELECT * FROM reponses WHERE question_id = :question_id");
    $requete->execute(array('question_id' => $question_id));
    $reponses = $requete->fetchAll(PDO::FETCH_ASSOC);

    return $reponses;
}


function insertReponse($user_id, $question_id, $response) {
    global $bdd;

    $requete = $bdd->prepare("INSERT INTO reponses (user_id, question_id, response) VALUES (:user_id, :question_id, :response)");
    $requete->execute(array('user_id' => $user_id, 'question_id' => $question_id, 'response' => $response));
}




   
    
    
?>
