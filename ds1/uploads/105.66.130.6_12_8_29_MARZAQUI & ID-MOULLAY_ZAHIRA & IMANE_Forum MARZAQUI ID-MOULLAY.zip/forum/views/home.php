<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>home</title>
    <style>
body{
   display: flex;
   justify-content: center;
   align-items: center; 
   margin-top: 80px;
   background: #34495e;
}
  * {
    padding: 0px;
    margin: 0px;
    box-sizing: border-box;
  }
  
  .containner {
    background: transparent;
    max-width: 500px;
    width: 90%;
    height: 500px;
    margin: 30px auto;
    border-radius: 10px;
  }
  
  .add {
    width: 100%;
    background: #fff;
    margin: 0px auto;
    padding: 10px;
    border-radius: 5px;
  }
  
  .add input {
    display: block;
    width: 95%;
    height: 40px;
    margin: 10px auto;
    border: 2px solid #ccc;
    font-size: 16px;
    border-radius: 5px;
    padding: 0px 5px;
  }
  
  .add button {
    display: block;
    width: 95%;
    height: 40px;
    margin: 0px auto;
    border: none;
    outline: none;
    background: #0088FF;
    color: #fff;
    font-family: sans-serif;
    font-size: 16px;
    border-radius: 5px;
    cursor: pointer;
  }
  
  .add button:hover {
    box-shadow: 0 2px 2px 0 #ccc, 0 2px 3px 0 #ccc;
    opacity: 0.7;
  }
  
  .add button span {
    border: 1px solid #fff;
    border-radius: 50%;
    display: inline-block;
    width: 20px;
    height: 20px;
  }
   .containner2{
    width: 100%;
    background: #fff;
    margin: 20px auto;
    padding: 10px;
    border-radius: 5px;
   }
   
    </style>
</head>

<body>
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
   <link rel="stylesheet" href="style.css">
    <title>todo</title>
</head>
<body>
    
   <div class="containner">
    <div class="add">
        <form action="">
            <input type="text" name="title" placeholder="Votre question ici..." />
            <button type="submit">Envoyer</button>
        </form>    
    </div> 
  </div>
  <div class="containner">
         

  </div>
</body>
</html>