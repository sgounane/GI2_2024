<?php
require_once("../models/db.php");

if(isset($_POST["submit"]) ){
    $nom = $_POST["nom"];
    $email = $_POST["email"];
    $password = $_POST["password"];
    $confirmerPassword  = $_POST["confirmer"];
    if (($password === $confirmerPassword)) {
        $password_hasshed = password_hash($password, PASSWORD_BCRYPT);
        adduser($nom,$email,$password);
    }
    else 
    echo "incorect password";
}






?>