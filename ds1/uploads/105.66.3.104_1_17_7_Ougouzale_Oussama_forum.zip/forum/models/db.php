<?php

$host = "localhost";
$user = "root";
$db_name = "forum";
$password = "";

$conn = mysqli_connect($host, $user, $password, $db_name);
if (!$conn)
    die("Failed To connect to Database" . mysqli_connect_error());
function adduser($nom, $email, $password)
{
    global $conn;
    $sql = "INSERT INTO users VALUES (
        null,'$nom','$email','$password'
    )";
    $query = mysqli_query($conn, $sql);
    if ($query) {
        echo "<script> alert('l\'utilisateur ajouté')
        window.location = '../views/login.php';
        </script>";
    }
}
function getUserByEmail($email)
{
    global $conn;
    $sql = "SELECT * FROM users WHERE email = '$email'";
    $result = mysqli_query($conn, $sql);
    return $result;
}

function getQuestions(){
    global $conn;
    $sql = "SELECT * FROM questions ORDER BY date DESC ";
    $result = mysqli_query($conn, $sql);
    return $result;
}

function getReponses($question_id){
    global $conn;
    $sql = "SELECT * FROM reponses WHERE question_id='$question_id' order by date asc";
    $result = mysqli_query($conn, $sql);
    return $result;
}

function ajouterReponse($id,$user_id,$reponse,$date){
    global $conn;
    $sql = "INSERT INTO reponses values(
        null,'$user_id','$id','$reponse','$date'
    )";
    $result = mysqli_query($conn, $sql);
    if($result)
    echo "<script> alert('reponse Ajouté ¡')</script>";
}
function ajouterQuestion($id,$user_id,$question,$date){
    global $conn;
    $sql = "INSERT INTO questions values(
        null,'$user_id','$question','$date'
    )";
    $result = mysqli_query($conn, $sql);
    if($result)
    echo "<script> alert('question Ajouté ¡')</script>";
}

function questionApi(){
    header('Content-Type: JSON');
$result2 = getQuestions();
$data = array();
$i=0;
while($row = mysqli_fetch_assoc($result2)){
    $data[$i]["id"] = $row["id"];
    $data[$i]["user_id"] = $row["user_id"];
    $data[$i]["question"] = $row["question"];
    $data[$i]["date"] = $row["date"];
    $i++;
}
echo json_encode( $data , JSON_PRETTY_PRINT );
}

//questionApi();