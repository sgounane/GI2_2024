// Script question.js

function getNewQuestions() {
    const db = new XMLHttpRequest();
    db.open("GET", "http://localhost:8031/forum/models/api.php", true);
    db.onload = function() {
        if (db.status === 200) {
            const questions = JSON.parse(db.responseText);

            const questionsContainer = document.querySelector(".part2");
            questionsContainer.innerHTML = "";
            for (const question of questions) {
                const questionElement = document.createElement("div");
                questionElement.classList.add("question");

                const questionTitle = document.createElement("h2");
                questionTitle.textContent = question.titre;
                questionElement.appendChild(questionTitle);

                const questionBody = document.createElement("p");
                questionBody.textContent = question.contenu;
                questionElement.appendChild(questionBody);

                questionsContainer.appendChild(questionElement);
            }
        } else {
            alert("Error getting questions: " + db.statusText);
        }
    };
    db.send();
}

setInterval(getNewQuestions, 30000);
