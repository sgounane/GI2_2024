
function getNewReplies() {
    const db = new XMLHttpRequest();
    db.open("GET", "http://localhost:8031/forum/models/api.php", true);
    db.onload = function() {
        if (db.status === 200) {
            const replies = JSON.parse(db.responseText);

            const repliesContainer = document.querySelector(".part2");
            repliesContainer.innerHTML = "";
            for (const reply of replies) {
                const replyElement = document.createElement("div");
                replyElement.classList.add("reply");

                const replyAuthor = document.createElement("h3");
                replyAuthor.textContent = reply.auteur;
                replyElement.appendChild(replyAuthor);

                const replyBody = document.createElement("p");
                replyBody.textContent = reply.contenu;
                replyElement.appendChild(replyBody);

                repliesContainer.appendChild(replyElement);
            }
        } else {
            alert("Error getting replies: " + db.statusText);
        }
    };
    db.send();
}

setInterval(getNewReplies, 30000);
