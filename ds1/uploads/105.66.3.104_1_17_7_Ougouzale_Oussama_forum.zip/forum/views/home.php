<?php
session_start();
require_once("../models/db.php");

$questions = getQuestions();


foreach ($questions as $question) {
    $id1 = $question["user_id"];
    $sql = "SELECT email FROM users WHERE id='$id1'";
    $result1 = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result1);
    $userEmail = $row["email"];
    $questionV = $question["question"];
    $date = date("Y-m-d");
}
if (isset($_POST["submit"])) {
    ajouterQuestion($question["id"], $_SESSION["user"]["id"], $_POST["data"], $date);
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="../style.css">
</head>

<body>
    <div class="container">
        <?php
        if (isset($_SESSION["user"])) {
            echo "
        <div class='part1'>
            <form action='' method='post'>
                <div class='div'>
                    <div class='info'>
                        <a href='logout.php'>Logout</a>
                    </div>
                    <div class='question'>
                        <input type='text' name ='data' placeholder='Votre question ici ....'>
                    </div>
                    <div class='reponse'>
                        <button type='submit' name='submit'>Envoyer</button>
                    </div>
                </div>
            </form>
        </div>";
        } else {
            echo "
            <div class='part1'>
            <form action='' method='post'>
                <div class='div'>
                    <div class='info'>
                        <a href='login.php'>Login</a>
                    </div>
                    
                </div>
            </form>
        </div>";
        }
        ?>
        <div class="part2">
            <?php
            foreach ($questions as $question) {
                $id = $question["user_id"];
                $sql = "SELECT email FROM users WHERE id='$id'";
                $result1 = mysqli_query($conn, $sql);
                $row = mysqli_fetch_assoc($result1);
                $userEmail = $row["email"];
                $questionV = $question["question"];
                echo "
            <div class='div'>
                <div class='info'>
                    <span>" . $question["date"] . "</span>
                    <span class='spn'>" . $userEmail . "</span>
                </div>
                <div class='question'>";
                echo "<input type='text' value=\"$questionV\" placeholder='une question ......' readonly> ";
                echo " </div>
                <div class='reponse'>";
                echo ' <a href="question.php?id=' . $question["id"] . '">Réponses</a>';
                echo "</div>
            </div>";
            }
            ?>
        </div>
    </div>
    <script src="../public/question.js"></script>
    <script src="../public/reponses.js"></script>
</body>

</html>