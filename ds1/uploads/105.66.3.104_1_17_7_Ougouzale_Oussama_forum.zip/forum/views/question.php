<?php
session_start();
require_once("../models/db.php");

$id = $_GET["id"];
$repones = getReponses($id);

foreach ($repones as $reponse) {
    $id1 = $reponse["user_id"];
    $sql = "SELECT email FROM users WHERE id='$id1'";
    $result1 = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result1);
    $userEmail = $row["email"];
    $reponseV = $reponse["reponse"];
    $date = date("Y-m-d");
}
if (isset($_POST["submit"])) {
    ajouterReponse($_GET["id"], $_SESSION["user"]["id"], $_POST["data"], $date);
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../style.css">
</head>

<body>
    <div class="container">
        <?php
        if (isset($_SESSION["user"])) {
            echo "
        <div class='part1'>
            <form action='question.php?id=$id' method='post'>
                <div class='div'>
                    <div class='info'>
                        <a href='home.php'>Home</a>
                        <a href='logout.php'>Logout</a>
                    </div>
                    <div class='question'>
                        <input type='text' name='data' placeholder='Votre reponse ici ....' required>
                    </div>
                    <div class='reponse'>
                        <button type='submit' name='submit'>Envoyer</button>
                    </div>
                </div>
            </form>
        </div>";
        } else {
            echo "
            <div class='part1'>
            <form action='' method='post'>
                <div class='div'>
                    <div class='info'>
                        <a href='login.php'>Login</a>
                    </div>
                </div>
            </form>
        </div>";
        }
        ?>
        <div class="part2">
            <?php
            foreach ($repones as $reponse) {
                $id = $reponse["user_id"];
                $sql = "SELECT email FROM users WHERE id='$id'";
                $result1 = mysqli_query($conn, $sql);
                $row = mysqli_fetch_assoc($result1);
                $userEmail = $row["email"];
                $reponseV = $reponse["reponse"];
                echo "
            <div class='div'>
                <div class='info'>
                    <span>" . $reponse["date"] . "</span>
                    <span class='spn'>" . $userEmail . "</span>
                </div>
                <div class='reponse1'>";
                echo "<input type='text' value=\"$reponseV\" placeholder='une reponse ......' readonly> ";
                echo " </div>
            </div>
            ";
            }
            ?>
        </div>
    </div>

    <script src="../public/question.js"></script>
    <script src="../public/reponses.js"></script>
</body>

</html>