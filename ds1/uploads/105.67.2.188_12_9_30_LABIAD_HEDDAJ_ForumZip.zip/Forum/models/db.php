<?php
function connect(){
    try {
        $db = new PDO('mysql:host=localhost;dbname=forum', 'root', '');
        return $db;
        }catch(PDOException $e){
            echo $e->getMessage();
            //exit(-1);
            die();
        }

}
$conn=connect();
function adduser($nom, $email, $password) {
    global $conn;
    $req = $conn->prepare("INSERT INTO users (nom, email, password) VALUES (:nom, :email, :password)");
    $req->execute(["nom" => $nom, "email" => $email, "password" => $password]);
}
function getUserByEmail($email){
    global $conn;
    $req = $conn->prepare("SELECT * FROM users WHERE email=:email");
    $req->execute(["email"=>$email]);
    $users=$req->fetch(PDO::FETCH_OBJ);
    return $users;
}
function getQuestions(){
    global $conn;
    $req = $conn->prepare("SELECT * FROM questions");
    $req->execute();
    $question=$req->fetchAll(PDO::FETCH_OBJ);
    return $question;
}
function getReponses($question_id){
    global $conn;
    $req = $conn->prepare("SELECT reponse FROM reponses Where question_id=:question_id");
    $req->execute(['question_id'=>$question_id]);
    $reponse=$req->fetch(PDO::FETCH_OBJ);
    return $reponse;
}
function addQuestion($question,$userId,$dte){
    global $conn;
    $req = $conn->prepare("INSERT INTO questions (user_id,question,dte) VALUES (:u, :q, :d)");
    $req->execute(["u" => $userId, "q" => $question, "d" => $dte]);
}
function addReponse($reponse,$dte,$userId,$questionId){
    global $conn;
    $req = $conn->prepare("INSERT INTO reponses (reponse,dte,user_id,question_id) VALUES (:r, :d, :u,:q)");
    $req->execute(["r"=>$reponse,"d" => $dte,"u" => $userId, "q" => $questionId]);
}

?>