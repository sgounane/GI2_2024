<?php
session_start();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>home</title>
    <link rel="stylesheet" href="../views/style.css">
</head>
<body>
    
    <nav>
        <a href="login.php">Login</a>
        <a href="../controllers/logout.php">Logout</a>
    </nav>
   <div class="con">
   <form action="../controllers/addquestions.php" method="POST">
        <input type="text" name="question" placeholder="votre question ici ..."><br>
        <input type="submit" value="envoyer"name="envoyer">
    </form>
    <div class="container">
    <div class="q1">
    <p>date email</p>
    <input type="text"placeholder="la question" name="q">
    <a href="../views/question.php">reponse</a>
    </div>
    <div class="q2">
    <p>date email</p>
    <input type="text"placeholder="la question" name="q">
    <a href="../views/question.php">reponse</a>
    </div>
    </div>
   </div>


    
</body>
</html>