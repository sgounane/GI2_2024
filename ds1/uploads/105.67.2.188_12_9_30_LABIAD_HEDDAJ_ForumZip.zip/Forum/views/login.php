<?php
session_start();
if(isset($_SESSION["user"])) {
  header("Location: ../views/home.php");
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    
</head>
<body>
    <form action="../controllers/auth.php" method="POST">
    <?php
            if(isset($_SESSION["error"])){
                echo '<span class="error-msg">'.$_SESSION["error"].'</span>';
                unset($_SESSION["error"]); // Supprimer l'erreur après l'avoir affichée
            }
        ?>
<div class="mb-3">
    <label  class="form-label">Email</label>
    <input type="email" class="form-control" name="email">
  </div>
  <div class="mb-3">
    <label class="form-label">mot de passe</label>
    <input type="password" class="form-control" name="pwd">
  </div>
  <button type="submit" class="btn btn-primary" name="login">login</button>
  <p>vous n avez pas de compte ?<a href="../views/register.php">Register</a></p>
    </form>
</body>
</html>