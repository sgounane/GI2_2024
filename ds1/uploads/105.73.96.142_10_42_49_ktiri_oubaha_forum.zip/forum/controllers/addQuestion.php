<?php
session_start();
include_once("../models/db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["add"])) {
        $question = $_POST["question"];

        // Check if the user is authenticated
        if (isset($_SESSION["user"])) {
            $user_id = $_SESSION["user"]["id"];

            // Add the question to the database
            $quest = addQuestion($question, $user_id);

            // Check if the question was added successfully
            if ($quest) {
                echo "added";
                // Redirect to home page
                header("Location: ../views/home.php");
                exit();
            } else {
                // Handle error while adding question
                echo "Error: Failed to add question";
            }
        } else {
            // Redirect to login page or handle unauthorized access
            header("Location: ../views/login.php");
            exit();
        }
    }
}
?>