<?php
session_start();
include_once("../models/db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["add"])) {
        $response = $_POST["response"];
        $question_id = $_POST["question_id"]; // Assuming you have a way to get the question_id

        // Check if the user is authenticated
        if (isset($_SESSION["user"])) {
            $user_id = $_SESSION["user"]["id"];

            // Add the response to the database
            $result = addReponse($user_id, $question_id, $response);

            // Check if the response was added successfully
            if ($result) {
                echo "added";
                // Redirect to home page or wherever needed
                header("Location: ../views/question.php");
                exit();
            } else {
                // Handle error while adding response
                echo "Error: Failed to add response";
            }
        } 
    }
}
?>

