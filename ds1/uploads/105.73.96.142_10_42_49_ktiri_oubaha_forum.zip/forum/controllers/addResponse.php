<?php
session_start();
include_once("../models/db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["add"])) {
        $reponse = $_POST["response"];
        $question_id = $_POST["question_id"];

        // Check if the user is authenticated
        if (isset($_SESSION["user"])) {
            $user_id = $_SESSION["user"]["id"];

            // Add the response to the database
            $result = addReponse($user_id,$question_id, $reponse);

            // Check if the response was added successfully
            if ($result) {
                // Redirect to question page
                header("Location: ../views/question.php?id=".$question_id);
                exit();
            } else {
                // Handle error while adding response
                echo "Error: Failed to add response";
            }
        } else {
            // Redirect to login page or handle unauthorized access
            header("Location: ../views/login.php");
            exit();
        }
    }
}
?>
