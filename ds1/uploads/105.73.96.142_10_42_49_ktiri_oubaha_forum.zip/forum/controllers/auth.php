<?php

include_once("../models/db.php");



if ($_SERVER["REQUEST_METHOD"] == "POST") {
    require_once "../models/db.php";
    $email = $_POST["email"];
    $password = $_POST["password"];

    $user = getUserByEmail($email);
    

    if ($user) {
        if (password_verify($password, $user["password"])) {
            session_start();
            $_SESSION["user"] = ["id" => $user["id"], "nom" => $user["nom"], "email" => $user["email"]];
            header("Location:../views/home.php");
            
        }else{
            echo "wrong password";
        }
    }else{
        echo "user not found";
    }
}
?>
