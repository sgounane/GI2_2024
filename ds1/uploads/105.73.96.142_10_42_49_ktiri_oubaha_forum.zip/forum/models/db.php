<?php
function connect(){
    try {
        $db = new PDO('mysql:host=localhost;dbname=forum', 'root', '');
        return $db;
        }catch(PDOException $e){
            echo $e->getMessage();
            //exit(-1);
            die();
        }

}

$db=connect();
function adduser($nom,$email,$password){
        global $db;
        $req=$db->prepare("INSERT INTO users(nom, email, password) VALUES(:n, :e, :p )");
        $req->execute(["n"=>$nom, "e"=>$email, "p"=>$password]);

    return $req;
    }



function getUserByEmail($email) {
    global $db;
  
    $stmt = $db->prepare("SELECT * FROM users WHERE email = :email");
    $stmt->bindParam(":email", $email);
    $stmt->execute();
    $user=$stmt->fetch(PDO::FETCH_ASSOC);
    return $user;
}

function getQuetions(){
        global $db;
        $req=$db->prepare("SELECT * FROM questions ORDER BY date DESC");
        //var_dump($req);
        $req->execute();
        //$prods=$req->fetchAll();
        $questions=$req->fetchAll(PDO::FETCH_OBJ);
    return $questions;
    }

        function  getQuestionsById($question_id) {
            global $db;
        
            // Récupérer les réponses
            $stmt = $db->prepare("SELECT * FROM reponses WHERE question_id = :question_id");
            $stmt->bindParam(":question_id", $question_id);
            $stmt->execute();
            $reponses = $stmt->fetchAll(PDO::FETCH_OBJ);
        
            // Récupérer les détails de la question associée
            $stmt_question = $db->prepare("SELECT * FROM questions WHERE id = :question_id");
            $stmt_question->bindParam(":question_id", $question_id);
            $stmt_question->execute();
            $question = $stmt_question->fetch(PDO::FETCH_OBJ);
        
            // Ajouter les détails de la question aux réponses
            foreach ($reponses as $reponse) {
                $reponse->question = $question;
            }
        
            return $reponses;
        }
        
        
    function getReponses($questionId) {
    global $db;
    $stmt = $db->prepare("SELECT * FROM reponses WHERE question_id = :question_id ORDER BY date DESC");
    $stmt->bindParam(':question_id', $questionId, PDO::PARAM_INT);
    $stmt->execute();

    $reponses = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return $reponses;
}
    // db.php
function addQuestion($question, $user_id) {
    global $db;
    $req = $db->prepare("INSERT INTO Questions (user_id, question, date) VALUES (:user_id, :question, NOW())");
    $req->execute(["user_id" => $user_id, "question" => $question]);
    return $req;
}

// db.php
function addReponse( $user_id,$question_id, $reponse,) {
    global $db;
    $req = $db->prepare("INSERT INTO Reponses (question_id, user_id, response, date) VALUES (:question_id, :user_id, :reponse, NOW()) ORDER BY date DESC");
    $req->execute(["question_id" => $question_id, "user_id" => $user_id, "reponse" => $reponse]);
    return $req;
}

?>