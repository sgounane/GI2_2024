// question.js

function fetchAndDisplayQuestions() {
    fetch('../views/home.php') // Assuming this script fetches all questions
        .then(response => response.json())
        .then(data => {
            const questionList = document.getElementById('questionList');
            questionList.innerHTML = ''; // Clear existing list before appending new questions
            data.forEach(question => {
                const questionItem = document.createElement('li');
                questionItem.textContent = question.question;
                questionList.appendChild(questionItem);
            });
        })
        .catch(error => console.error('Error fetching questions:', error));
}

// Execute the function every minute
setInterval(fetchAndDisplayQuestions, 60000);
