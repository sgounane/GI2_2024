// reponses.js

function fetchAndDisplayResponses() {
    // Assuming you have a similar script like getResponses.php that fetches responses
    fetch('../controllers/addResponse.php')
        .then(response => response.json())
        .then(data => {
            const responseList = document.getElementById('responseList');
            responseList.innerHTML = ''; // Clear existing list before appending new responses
            data.forEach(response => {
                const responseItem = document.createElement('li');
                responseItem.textContent = response.response;
                responseList.appendChild(responseItem);
            });
        })
        .catch(error => console.error('Error fetching responses:', error));
}

// Execute the function every minute
setInterval(fetchAndDisplayResponses, 60000);
