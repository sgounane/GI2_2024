CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(30),
    email VARCHAR(30),
    password VARCHAR(255)
);
 

