<?php
include_once("../models/db.php");
$questions=getQuetions();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <title>Dynamic Question Form</title>
</head>
<body>
<?php include_once("header.php");?>
<div class="container mt-5">
    <form id="questionForm" method="POST" action="../controllers/addQuestion.php">
        <div class="form-group">
            <label for="questionInput">Enter a Question:</label>
            <input type="text" class="form-control" id="questionInput" placeholder="Enter your question" name="question">
        </div>
        <button type="submit" class="btn btn-primary" name="add" style="position:relative;left:986px;">Add Question</button>
    </form>

    <div class="mt-3">
        <ul id="questionList" class="list-group"></ul>
        <article style="border:2px solid black;" >
        <?php foreach($questions as $quest) :?>
            <br>
                <div class="article"style="border:1px solid black; width:1000px;position:relative;left:40px;">
                    <div class="question"><?=$quest->question ?></div>
                    <div class="date"><?=$quest->date ?></div>

                    <a href=<?="question.php?id=".$quest->id ?>  class="detail">reponse</a>
                </div>
          
            <?php endforeach ?> 
            <br>
        </article>
        
            <!-- Questions will be dynamically added here -->
        
    </div>
</div>




</body>
</html>
