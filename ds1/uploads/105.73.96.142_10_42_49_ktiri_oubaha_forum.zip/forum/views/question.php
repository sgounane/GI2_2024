<?php
include_once("../models/db.php");

// Assuming you get the question ID from the URL parameters
$question_id = isset($_GET['id']) ? $_GET['id'] : null;

// Retrieve question details and responses
$reponses = getQuestionsById($question_id);

// Check if there are responses (assuming the question details are included in each response)
if (!empty($reponses)) {
    // Retrieve the question details from the first response (assuming they are the same for all responses)
    $question = $reponses[0]->question;

    // Output your HTML
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <!-- Your head content remains the same -->
    </head>
    <body>

        <?php include_once("header.php");?>
        <?php
            // Check if the user is authenticated
            
                ?>
               
                    <input type="hidden" name="question_id" value="<?= $question_id ?>">
                    <br><br><br>
                    <div class="form-group" style=" width:1100px;position:relative;left:130px; justify-content: center;">
                    <div class="container mt-5">
            <div class="question">
                <p><?= $question->question ?>  (<?= $question->date ?>)</p>
            </div>
            <?php 
             if (isset($_SESSION["user"])) {
                      ?> 
                       <form id="responseForm" method="POST" action="../controllers/addReponse.php">
                         <input type="text" class="form-control" id="responseInput" placeholder="Enter your response" name="response">
                        <input type="hidden" name="question_id" value="<?php echo $question_id; ?>">

                    </div>
                    <button type="submit" class="btn btn-primary" name="add"style="position:relative;left:963px;top:22px;">Add Response</button>
                </form>
                <?php
            }
            ?>
      
            <h2 style="left:12px; position:relative;color:rgb(33, 95, 203);">Responses:</h2>
            <ul id="responseList" class="list-group" style=" width:1100px;position:relative;left:12px; justify-content: center;">
                <?php foreach ($reponses as $response) : ?>
                    <li class="list-group-item" style="position:relative;left:1px;width:1000px;justify-content: center;width:1075px;" >  <?= $response->date ?><br><?= $response->response ?></li>
                <?php endforeach ?>
            </ul>

           
        </div>
    </body>
    </html>
    <?php
} else {
    // Handle the case where there are no responses or the question ID is invalid
    echo "Invalid question ID or no responses found.";
}
?>
