<?php

session_start();
require_once("../models/db.php");

if (isset($_POST["submit"])) {
    $email = $_POST["email"];
    $password = $_POST["password"];


    if (!$conn) {
        die("Connexion échouée : ");
    }

    $email = $_POST['email'];
    $password = $_POST['password'];

    $result = getUserByEmail($email);

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $storedPassword = $user['password'];

        if ($storedPassword === $password) {
            $_SESSION['user'] = [
                'nom' => $user['nom'],
                'email' => $user['email']
            ];
            header("Location: ../views/home.php");
        } else {
            echo "<script> alert('mot de passe incorect')
            window.location = '../views/login.php'</script>";
        }
    } else {
        echo "<script> alert('invalid Email')</script>";
    }
}
$conn->close();
