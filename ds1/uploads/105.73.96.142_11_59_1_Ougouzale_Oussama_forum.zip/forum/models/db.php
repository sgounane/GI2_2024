<?php

$host = "localhost";
$user = "root";
$db_name = "forum";
$password = "";

$conn = mysqli_connect($host, $user, $password, $db_name);
if (!$conn)
    die("Failed To connect to Database" . mysqli_connect_error());
function adduser($nom, $email, $password)
{
    global $conn;
    $sql = "INSERT INTO users VALUES (
        null,'$nom','$email','$password'
    )";
    $query = mysqli_query($conn, $sql);
    if ($query) {
        echo "<script> alert('l\'utilisateur ajouté')
        window.location = '../views/login.php';
        </script>";
    }
}
function getUserByEmail($email)
{
    global $conn;
    $sql = "SELECT * FROM users WHERE email = '$email'";
    $result = mysqli_query($conn, $sql);
    return $result;
}
