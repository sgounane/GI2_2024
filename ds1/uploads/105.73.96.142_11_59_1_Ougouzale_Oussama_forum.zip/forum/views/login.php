

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <style>
        button {
            margin-top: 20px;
        }

        form {
            border: 1px solid gray;
            border-radius: 4px;
            padding: 20px;
            box-shadow: 3px 3px 3px gray;
            width: 40%;
            margin: 100px auto;
        }

        .div {
            margin-top: 10px;
        }

        .invalid {
            border: 1px solid red;
            color: red;
        }
    </style>
</head>

<body>
    <form action="../controllers/auth.php" method="post">
        <h3 style="margin:34px auto;width:20%;color:gray" ;>Login</h3>
        <div class="form-group row div">
            <label for="inputPassword3" class="col-sm-4 col-form-label">Email</label>
            <div class="col-sm-8">
                <input type="email" name="email" class="form-control" id="inputPassword3" required>
            </div>
        </div>
        <div class="form-group row div">
            <label for="inputPassword3" class="col-sm-4 col-form-label">Mot de Passe</label>
            <div class="col-sm-8">
                <input type="password" name="password" class="form-control" id="inputPassword3" required>
            </div>
        </div>
        

        <div class="form-group row div">
            <div class="col-sm-10">
                <button type="submit" name="submit" class="btn btn-primary">Login</button>
            </div>
        </div>
    </form>
    <script>

    </script>
</body>

</html>