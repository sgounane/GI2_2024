<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <style>
        button {
            margin-top: 20px;
        }

        form {
            border: 1px solid gray;
            border-radius: 4px;
            padding: 30px;
            box-shadow: 3px 3px 3px gray;
            width: 50%;
            margin: 100px auto;
        }

        .div {
            margin-top: 10px;
        }

        .invalid {
            border: 1px solid red;
            color: red;
        }
    </style>
</head>

<body>
    <form action="../controllers/adduser.php" method="post">
        <h3 style="margin:34px auto;width:20%;color:gray" ;>Enregistrement</h3>
        <div class="form-group row div">
            <label for="inputEmail3" class="col-sm-6 col-form-label">Nom</label>
            <div class="col-sm-6">
                <input type="text" name="nom" class="form-control" id="inputEmail3" required>
            </div>
        </div>
        <div class="form-group row div">
            <label for="inputPassword3" class="col-sm-6 col-form-label">Email</label>
            <div class="col-sm-6">
                <input type="email" name="email" class="form-control" id="inputPassword3" required>
            </div>
        </div>
        <div class="form-group row div">
            <label for="inputPassword3" class="col-sm-6 col-form-label">Mot de Passe</label>
            <div class="col-sm-6">
                <input type="password" name="password" class="form-control" id="inputPassword3" required>
            </div>
        </div>
        <div class="form-group row div">
            <label for="inputPassword3" class="col-sm-6 col-form-label">Confirmer le mot de Passe</label>
            <div class="col-sm-6 ">
                <input type="password" name="confirmer" class="form-control " id="inputPassword3" required oninput="checkPasswords()">
            </div>
        </div>

        <div class="form-group row div">
            <div class="col-sm-10">
                <button type="submit" name="submit" class="btn btn-primary">Register</button>
            </div>
        </div>
    </form>

    <script>
        function checkPasswords() {
            var password = document.querySelector("input[name='password']").value;
            var passwordConfirmation = document.querySelector("input[name='confirmer']").value;
            var passwordConfirmationI = document.querySelector("input[name='confirmer']");

            if (password === passwordConfirmation) {
                passwordConfirmationI.style.boxShadow = "none";
                passwordConfirmationI.style.border = "1px solid black";
                document.querySelector("input[name='confirmer']").classList.remove("invalid");
            } else {
                if (passwordConfirmationI.value.length > 0) {
                    passwordConfirmationI.style.boxShadow = "0 0 10px black";
                    passwordConfirmationI.style.border = "2px solid red";
                document.querySelector("input[name='confirmer']").classList.add("invalid");
            }
            console.log(passwordConfirmation)
        }}
    </script>
</body>

</html>