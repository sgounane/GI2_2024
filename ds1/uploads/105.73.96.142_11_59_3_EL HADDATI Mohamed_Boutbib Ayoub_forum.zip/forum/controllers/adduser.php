<?php
session_start();
include_once("../models/db.php");

function check_password($password, $confirm_password) {
    if ($password === $confirm_password) {
          return true;
    } else {
          return false;
    }
}

$password = $_POST["password"];
$confirm_password = $_POST["confirm_password"];

if (check_password($password, $confirm_password)) {
    $_SESSION["user"] = array(
        "name" => $_POST["name"],
        "email" => $_POST["email"]
    );
    
    /*$_SESSION["user"]["name"] = $_POST["name"];
    $_SESSION["user"]["email"] = $_POST["email"];*/
    
    adduser($_POST["name"], $_POST["email"], password_hash($_POST["password"], PASSWORD_DEFAULT));
    echo $_SESSION["user"]["name"];
    header("Location: ../views/login.php");
} else {
    header("Location: ../views/register.php?error=1");
    exit();
}
?>