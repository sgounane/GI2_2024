<?php
session_start();
require_once("../models/db.php");
$user = getUserByEmail($_POST["email"]);
if(password_verify($_POST["password"], $user->password)){
    $_SESSION["user"] = array(
        "name" => $_POST["name"],
        "email" => $_POST["email"],
        "id" => $user->id
    );
    header("Location: ../views/home.php");
}
else {
    header("Location: ../views/login.php?error=1");
}


?>