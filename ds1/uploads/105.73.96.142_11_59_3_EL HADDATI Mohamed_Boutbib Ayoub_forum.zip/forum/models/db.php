<?php

function connect(){
    try{
        $db = new PDO('mysql:host=localhost;dbname=forum' , 'root', '');
        return $db;
    }
    catch(PDOException $e){
        echo $e->getMessage();
        die();
    }
}

$db = connect();

function adduser($nom,$email,$password){
    global $db;
    $req = $db->prepare("INSERT INTO users(nom, email, password) VALUES(:n, :e, :p)");
    $req->execute(["n"=>$nom, "e"=>$email, "p"=>$password]);

    return $req;
}

function getUserByEmail($email){
    global $db;
    $req = $db->prepare("SELECT * FROM users WHERE email=:email");
    $req->execute(["email"=>$email]);
    $user = $req->fetch(PDO::FETCH_OBJ);
    return $user;
}

function getUserByID($id){
    global $db;
    $req = $db->prepare("SELECT * FROM users JOIN questions ON users.id = questions.user_id");
    $req->execute();
    $user = $req->fetch(PDO::FETCH_OBJ);
    return $user;
}

function getQuestions(){
    global $db;
    $req = $db->prepare("SELECT question, DATE_FORMAT(date, '%Y-%m-%d %H:%i:%s'), user_id FROM questions");
    $req->execute();
    $questions = $req->fetchAll(PDO::FETCH_OBJ);
    return $questions;
}

function getReponses($question_id){
    global $db;
    $req = $db->prepare("SELECT * FROM reponses WHERE question_id=:question_id");
    $req->execute(["question_id"=>$question_id]);
    $reponses = $req->fetch(PDO::FETCH_OBJ);
    return $reponses;
}

function addQuestion($user_id, $question){
    global $db;
    $req = $db->prepare("INSERT INTO questions(user_id, question) VALUES(:u, :q)");
    $req->execute(["u"=>$user_id, "q"=>$question]);

    return $req;
}

function addReponse($user_id, $question_id, $reponse){
    global $db;
    $req = $db->prepare("INSERT INTO reponses(user_id, question_id, reponse) VALUES(:u, :q, :r)");
    $req->execute(["u"=>$user_id, "q"=>$question_id, "r"=>$reponse]);

    return $req;
}
?>