<?php
session_start();
include_once("../models/db.php");

if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['register']) && isset($_POST['nom']) && !empty($_POST['nom']) && isset($_POST['email']) && !empty($_POST['email']) && isset($_POST['password']) && !empty($_POST['password']) && isset($_POST['Cpassword']) && !empty($_POST['Cpassword'])) {

    adduser($_POST['nom'], $_POST['email'],$_POST['password'] );
}
?>
