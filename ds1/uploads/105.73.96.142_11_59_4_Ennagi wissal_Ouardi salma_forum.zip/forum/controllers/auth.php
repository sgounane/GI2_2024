<?php
session_start();
include_once("../models/db.php");


if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['login']) && isset($_POST['email']) && !empty($_POST['email']) && isset($_POST['password']) && !empty($_POST['password'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $user = getUserByEmail($email);
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user'] = ['nom' => $user['nom'], 'email' => $user['email']];
        header("Location: ../views/home.php");
        exit();
    } else {
        $_SESSION['error_message'] = "Email ou mot de passe incorrect.";
        header("Location: ../views/login.php");
        exit();
    }
}
?>

















