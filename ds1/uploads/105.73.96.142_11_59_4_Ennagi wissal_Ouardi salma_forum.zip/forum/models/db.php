<?php
function connect(){
    try {
        $db = new PDO('mysql:host=localhost;dbname=forum', 'root', '');
        return $db;
    } catch(PDOException $e) {
        echo $e->getMessage();
        die();
    }
}
$db = connect();
function adduser($nom,$email,$password){
    global $db;
    $hash = password_hash($password, PASSWORD_BCRYPT);
    $req = $db->prepare("INSERT INTO users (nom,email,password) VALUES (:nom,:email,:password)");
    $req->execute(['nom' => $nom , 'email'=> $email , 'password'=>$hash]);
    return $req;
}
function getUserByEmail($email) {
    global $db;
    $req = $db->prepare("SELECT * FROM users WHERE email=:email ");
    $req->execute(["email" => $email]);
    $user = $req->fetch(PDO::FETCH_ASSOC);
    return $user;
}
function getQuestions() {
    global $db;
    $query = $db->query("SELECT * FROM questions ORDER BY date DESC");
    $questions = $query->fetchAll(PDO::FETCH_ASSOC);
    return $questions;
}
function getReponses($question_id) {
    global $db;
    $query = $db->prepare("SELECT * FROM reponses WHERE question_id = :question_id ORDER BY date DESC");
    $query->execute(['question_id' => $question_id]);
    $reponses = $query->fetchAll(PDO::FETCH_ASSOC);
    return $reponses;
}
function addQuestion($user_id, $question) {
    global $db;
    $query = $db->prepare("INSERT INTO questions (user_id, question, date) VALUES (:user_id, :question, NOW())");
    $query->execute(['user_id' => $user_id, 'question' => $question]);
    return $query;
}

function addReponse($user_id, $question_id, $response) {
    global $db;
    $query = $db->prepare("INSERT INTO reponses (user_id, question_id, response, date) VALUES (:user_id, :question_id, :response, NOW())");
    $query->execute(['user_id' => $user_id, 'question_id' => $question_id, 'response' => $response]);
    return $query;
}
?>