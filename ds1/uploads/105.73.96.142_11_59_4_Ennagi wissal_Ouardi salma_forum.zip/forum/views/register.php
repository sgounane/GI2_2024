<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
<form action=" ../controllers/adduser.php" method="post">
<div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Nom:</label>
    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="nom" required>
  </div>
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Email:</label>
    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="email" required>
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Mot de passe:</label>
    <input type="password" class="form-control" id="exampleInputPassword1" name="password" required>
    <h6 style="color: red;" id="erreur2"></h6>
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Confirmer Mot de passe:</label>
    <input type="password" class="form-control" id="exampleInputPassword2" name="Cpassword" required>
    <h6 style="color: red;" id="erreur3"></h6>
  </div>
  <button type="submit" class="btn btn-primary" name="register">Register</button>
</form>
<script>
    let pass = document.getElementsByName("password")[0];
    let cpass = document.getElementsByName("Cpassword")[0];
    let erreur2 = document.getElementById("erreur2");
    let erreur3 = document.getElementById("erreur3");

    pass.addEventListener("input", function () {
        if (pass.value.length < 8) {
            erreur2.innerHTML = "Le mot de passe doit contenir au moins 8 caractères";
        } else {
            erreur2.innerHTML = "";
        }
    });

    cpass.addEventListener("input", function () {
        if (cpass.value !== pass.value) {
            erreur3.innerHTML = "Les deux mots de passe ne correspondent pas";
        } else {
            erreur3.innerHTML = "";
        }
    });
</script>
</body>
</html>
