<?php
session_start();
include_once("../models/db.php");

if (isset($_POST["register"])) {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $password = $_POST["password"];
    $confirmPassword = $_POST["confirmPassword"];

    if ($password !== $confirmPassword) {
        echo "Passwords do not match. Please try again.";
        exit();
    }

    if (emailExists($email)) {
        echo "Email already exists. Please choose a different email address.";
        exit();
    }

    $passwordHash = password_hash($password, PASSWORD_DEFAULT);
    $req = addUser($name, $email, $passwordHash);

    if ($req) {
        $_SESSION["user"] = $name;
        header("Location: ../views/home.php");
        exit();
    } else {
        echo "Registration failed. Please try again.";
    }
}


?>
