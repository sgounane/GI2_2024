<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
include_once("../models/db.php");


if (isset($_POST["login"])) {
    $email = $_POST["email"];
    $password = $_POST["password"];

    $user = getUser($email);

    if ($user && password_verify($password, $user->password)) {
        $_SESSION["user"] = $user->email;
        header("Location: ../views/home.php");
        exit(); 
    } else {
        echo "Login failed. Please check your email and password.";
    }
} else {
    echo "Invalid request. Please provide email and password.";
}
