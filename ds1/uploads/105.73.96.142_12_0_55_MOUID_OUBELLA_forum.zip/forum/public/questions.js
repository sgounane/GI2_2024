$(document).ready(function () {
    function updateQuestions() {
        $.ajax({
            type: "GET",
            url: "api.php", // Remplacez "api.php" par le script qui renvoie les nouvelles questions
            success: function (data) {
                // Mettez à jour la liste des questions sur la page
                $("#questionsList").empty();
                var questions = JSON.parse(data);
                questions.forEach(function (question) {
                    var listItem = $("<li>").text(
                        question.date +
                            " - " +
                            question.nom +
                            " - " +
                            question.question
                    );
                    $("#questionsList").append(listItem);
                });
            },
        });
    }

    // Mettez à jour les questions toutes les 30 secondes
    setInterval(updateQuestions, 30000);
});
