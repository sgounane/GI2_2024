$(document).ready(function () {
    function updateResponses() {
        $.ajax({
            type: "GET",
            url: "api.php", // Remplacez "api.php" par le script qui renvoie les nouvelles réponses
            success: function (data) {
                // Mettez à jour la liste des réponses sur la page
                $("#responsesList").empty();
                var responses = JSON.parse(data);
                responses.forEach(function (response) {
                    var listItem = $("<li>").text(
                        response.response + " - " + response.date
                    );
                    $("#responsesList").append(listItem);
                });
            },
        });
    }

    // Mettez à jour les réponses toutes les 30 secondes
    setInterval(updateResponses, 30000);
});
