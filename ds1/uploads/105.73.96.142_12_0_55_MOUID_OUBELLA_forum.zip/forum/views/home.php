<?php

session_start();
include_once("../models/db.php");

if (isset($_POST["addQuestion"])) {
    $questionText = $_POST["questionText"];
    $userId = getUserIdByEmail($_SESSION["user"]); 

    addQuestion($userId, $questionText);

    $questions = getQuestions();
}

$questions = getQuestions();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <h2 class="mb-4">Questions</h2>

                <form action="" method="post">
                    <div class="mb-3">
                        <label for="questionText" class="form-label">Ask a new question:</label>
                        <input type="text" class="form-control" name="questionText" id="questionText" required>
                    </div>
                    <button type="submit" class="btn btn-primary" name="addQuestion">Submit Question</button>
                </form>

                <ul class="list-group mt-4">
                    <?php foreach ($questions as $question) : ?>
                        <li class="list-group-item">
                            <?= (new DateTime($question->date))->format('F j, Y, g:i a') ?> - <?= $question->nom ?> - <?= $question->question ?> - <?= getUserById($question->user_id)->nom ?>
                            <a href="question.php?id=<?= $question->id ?>">Responses</a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="../public/questions.js"></script> 
    <script src="../public/responses.js"></script>
</body>

</html>