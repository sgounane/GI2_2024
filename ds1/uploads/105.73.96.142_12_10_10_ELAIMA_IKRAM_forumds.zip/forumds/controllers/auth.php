<?php
session_start();
include('../models/db.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $password = $_POST["password"];
    $user = getUserByEmail($email);

    if ($user) {
        if (password_verify($password, $user['password'])) {
            
            $_SESSION['user'] = [
                'nom' => $user['nom'],
                'email' => $user['email']
            ];

            
            header("Location: home.php");
            exit();
        } else {
            header("Location: login.php?error=Mot de passe incorrect");
            exit();
        }
    } else {
        header("Location: login.php?error=Email non trouvé");
        exit();
    }
} else {

    header("Location: login.php?error=Méthode non autorisée");
    exit();
}
?>
