<?php

$servername = "localhost";
$username = "root";
$password = " ";
$dbname = "forum";

function connectDB() {
    global $servername, $username, $password, $dbname;

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Vérifiez connexion
    if ($conn->connect_error) {
        die("Échec de la connexion à la base de données : " . $conn->connect_error);
    }

    return $conn;
}

function addUser($nom, $email, $password) {
    global $conn;

    $req = $conn->prepare("INSERT INTO Users (nom, email, password) VALUES(:n, :e, :p)");
    $req->execute(["n" => $nom, "e" => $email, "p" => $password]);

    return $req;
}

function getQuestions() {
    global $conn;

    $result = $conn->query("SELECT Q.id, Q.date, U.nom AS nom_user, U.email AS email_user, Q.question
                            FROM Questions Q
                            INNER JOIN Users U ON Q.user_id = U.id
                            ORDER BY Q.date DESC");

    if ($result) {
        return $result->fetch_all(MYSQLI_ASSOC);
    } else {
        return [];
    }
}

function getReponses($question_id) {
    global $conn;

    $req = $conn->prepare("SELECT R.id, R.date, U.nom AS nom_user, U.email AS email_user, R.response
                          FROM Reponses R
                          INNER JOIN Users U ON R.user_id = U.id
                          WHERE R.question_id = ?
                          ORDER BY R.date DESC");
    $req->bind_param("i", $question_id);
    $req->execute();

    $result = $req->get_result();

    if ($result) {
        return $result->fetch_all(MYSQLI_ASSOC);
    } else {
        return [];
    }
}

function insertQuestion($user_id, $question, $date) {
    global $conn;

    $req = $conn->prepare("INSERT INTO Questions (user_id, question, date) VALUES (?, ?, ?)");
    $req->bind_param("iss", $user_id, $question, $date);
    $req->execute();

    return $req;
}

function insertReponse($user_id, $question_id, $response, $date) {
    global $conn;

    $req = $conn->prepare("INSERT INTO Reponses (user_id, question_id, response, date) VALUES (?, ?, ?, ?)");
    $req->bind_param("iiss", $user_id, $question_id, $response, $date);
    $req->execute();

    return $req;
}

?>
