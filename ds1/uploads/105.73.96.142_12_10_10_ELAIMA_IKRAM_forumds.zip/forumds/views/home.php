<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>

    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="#">Forum</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto">
            <?php
            session_start();

            if (isset($_SESSION['user'])) {
                echo '<li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>';
            } else {
                echo '<li class="nav-item"><a class="nav-link" href="login.php">Login</a></li>';
                echo '<li class="nav-item"><a class="nav-link" href="register.php">Register</a></li>';
            }
            ?>
        </ul>
    </div>
</nav>

<div class="container mt-5">
    <h2 class="mb-4">Liste des Questions</h2>

    <?php
    include('db.php');

    $questions = getQuestions();

    foreach ($questions as $question) {
        echo '<div class="card mb-3">';
        echo '<div class="card-body">';
        echo '<p>Date: ' . $question['date'] . '</p>';
        echo '<p>Nom utilisateur: ' . $question['nom_user'] . '</p>';
        echo '<p>Email utilisateur: ' . $question['email_user'] . '</p>';
        echo '<p>Question: ' . $question['question'] . '</p>';
        echo '<p>Réponses: <a href="question.php?id=' . $question['id'] . '">Voir les réponses</a></p>';
        echo '</div>';
        echo '</div>';
    }
    ?>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com
