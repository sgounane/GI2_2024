<?php
include_once("../models/db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["submit"])) {
        $nom = $_POST["nom"];
        $email = $_POST["email"];
        $password = $_POST["password"];
        $conf_password = $_POST["conf_password"];

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo "Adresse e-mail invalide";
        } else {
            if ($password === $conf_password) {
                $mot_hache = password_hash($password, PASSWORD_DEFAULT);

                adduser($nom, $email, $mot_hache);

            } else {
                echo "mot de passe incorrect !!!";
            }
        }
    }
}
// header("Location:../views/register.php");
?>
