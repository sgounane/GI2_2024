<?php
session_start();
include_once("../models/db.php");
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["login"])) {
        $email = trim($_POST["email"]);
        $password = trim($_POST["password"]);
        
        
        $user=getUserByEmail($email);

            if ($user ){
            // if(password_verify($password,$user["password"]) ) {
                
                $_SESSION["user"] = ["nom" => $user["nom"], 
                                    "email" => $user["email"]];
               

                header("Location: ../views/home.php"); 
                exit();}
            } else {
            
                header("Location: ../views/home.php"); // Redirection vers la page de connexion
                exit();
            }
        } 
    

?>
