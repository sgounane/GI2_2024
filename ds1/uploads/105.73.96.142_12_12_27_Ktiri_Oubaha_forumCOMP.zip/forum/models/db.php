<?php
function connect(){
    try {
        $db = new PDO('mysql:host=localhost;dbname=forum', 'root', '');
        return $db;
        }catch(PDOException $e){
            echo $e->getMessage();
            //exit(-1);
            die();
        }

}

$db=connect();
function adduser($nom,$email,$password){
        global $db;
        $req=$db->prepare("INSERT INTO users(nom, email, password) VALUES(:n, :e, :p )");
        $req->execute(["n"=>$nom, "e"=>$email, "p"=>$password]);

    return $req;
    }



function getUserByEmail($email) {
    global $db;
  
    $stmt = $db->prepare("SELECT * FROM users WHERE email = :email");
    $stmt->bindParam(":email", $email);
    $stmt->execute();
    $user=$stmt->fetchAll(PDO::FETCH_ASSOC);
    return $user;
}

function getQuetions(){
        global $db;
        $req=$db->prepare("SELECT * FROM questions");
        //var_dump($req);
        $req->execute();
        //$prods=$req->fetchAll();
        $questions=$req->fetchAll(PDO::FETCH_OBJ);
    return $questions;
    }

    function getReponses($question_id){
        global $db;
        $req=$db->prepare("SELECT * FROM questions");
        //var_dump($req);
        $req->execute();
        //$prods=$req->fetchAll();
        $questions=$req->fetchAll(PDO::FETCH_OBJ);
    return $questions;
    }


?>