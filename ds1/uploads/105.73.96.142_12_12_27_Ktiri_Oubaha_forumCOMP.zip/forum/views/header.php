<?php session_start();?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Q/R</title>
    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="../styles/style.css">
</head>
<body>
    <header>
        <h1 style="text-align:center;">Question/Reponses:</h1>
        <nav>
            
            <?php if(isset($_SESSION["user"])):?>
                <a style="text-align:center;" href="logoot.php">Logout</a>
            <?php else:?>
                <a style="text-align:center;" href="login.php">Login</a>
            <?php endif ?>
        </nav>
    </header>