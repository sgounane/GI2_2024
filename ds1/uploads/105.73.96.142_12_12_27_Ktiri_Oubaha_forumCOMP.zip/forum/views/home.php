<?php
include_once("../models/db.php");
$questions=getQuetions();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <title>Dynamic Question Form</title>
</head>
<body>
<?php include_once("header.php");?>
<div class="container mt-5">
    <form id="questionForm">
        <div class="form-group">
            <label for="questionInput">Enter a Question:</label>
            <input type="text" class="form-control" id="questionInput" placeholder="Enter your question">
        </div>
        <button type="button" class="btn btn-primary" onclick="addQuestion()">Add Question</button>
    </form>

    <div class="mt-3">
        <h2>Questions:</h2>
        <ul id="questionList" class="list-group"></ul>
        <article>
        
        <?php foreach($questions as $quest) :?>
                <div class="article">
                    <div class="question"><?=$quest->question ?></div>
                    <div class="date"><?=$quest->date ?></div>

                    <a href=<?="question.php?id=".$quest->id ?>  class="detail">reponse</a>
                </div>
            <?php endforeach ?> 
        </article>
        
            <!-- Questions will be dynamically added here -->
        
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

<script>
    function addQuestion() {
        var questionInput = document.getElementById('questionInput');
        var questionList = document.getElementById('questionList');

        // Get the value of the input
        var questionText = questionInput.value.trim();

        // Check if the input is not empty
        if (questionText !== "") {
            // Create a new list item with a link to the response (you can replace '#' with the actual response link)
            var listItem = document.createElement('li');
            listItem.className = 'list-group-item';
            listItem.innerHTML = '<a href="question.php">' + questionText + '</a>'; // Concatenate the HTML content
            
            // Append the new list item to the question list
            questionList.appendChild(listItem);

            // Clear the input field
            questionInput.value = "";
        }
    }
</script>


</body>
</html>
