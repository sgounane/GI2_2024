<?php


include 'path/vers/db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nom = $_POST["nom"];
    $email = $_POST["email"];
    $password = $_POST["password"];

    
    $existingUser = getUserByEmail($email);

    if ($existingUser === null) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

     
        adduser($nom, $email, $hashedPassword);

        header("Location: login.php");
        exit();
    } else {
       
        header("Location: register.php?error=Email déjà utilisé");
        exit();
    }
} else {
  
    header("Location: register.php");
    exit();
}

$conn->close();
?>
