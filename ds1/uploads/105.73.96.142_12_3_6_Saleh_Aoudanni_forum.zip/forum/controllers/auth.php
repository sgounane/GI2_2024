<?php

include 'models/db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $password = $_POST["password"];

   
    $user = getUserByEmail($email);

    if ($user !== null) {
    
        if (password_verify($password, $user["password"])) {
          
            session_start();
            $_SESSION["user"] = [
                "id" => $user["id"],
                "nom" => $user["nom"],
                "email" => $user["email"]
            ];

          
            header("Location: home.php");
            exit();
        } else {
           
            header("Location: login.php?error=Mot de passe incorrect");
            exit();
        }
    } else
}