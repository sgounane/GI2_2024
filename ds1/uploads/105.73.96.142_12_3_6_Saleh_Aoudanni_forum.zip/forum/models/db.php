<?php
 

$servername = "localhost";
$username = "votre_nom_utilisateur";
$password = "votre_mot_de_passe";
$dbname = "forum";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("La connexion a échoué : " . $conn->connect_error);
}

function adduser($nom, $email, $hashedPassword) {
    global $conn;

    $nom = $conn->real_escape_string($nom);
    $email = $conn->real_escape_string($email);

    $sql = "INSERT INTO Users (nom, email, password) VALUES ('$nom', '$email', '$hashedPassword')";

    if ($conn->query($sql) === TRUE) {
        echo "Utilisateur ajouté avec succès.";
    } else {
        echo "Erreur lors de l'ajout de l'utilisateur : " . $conn->error;
    }
}



function getUserByEmail($email) {
    global $conn;

    $email = $conn->real_escape_string($email);
    $sql = "SELECT * FROM Users WHERE email = '$email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        return $result->fetch_assoc();
    } else {
        return null;
    }
}













