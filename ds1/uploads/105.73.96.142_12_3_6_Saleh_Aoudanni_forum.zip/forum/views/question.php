<?php


include 'models/db.php';

if (isset($_GET['question_id'])) {
    $question_id = $_GET['question_id'];


    $reponses = getReponses($question_id);

    
    foreach ($reponses as $reponse) {
        echo "Date: " . $reponse['date'] . "<br>";
        echo "Nom utilisateur: " . $reponse['nom_user'] . "<br>";
        echo "Email utilisateur: " . $reponse['email_user'] . "<br>";
        echo "Réponse: " . $reponse['response'] . "<br><br>";
    }

   
    session_start();
    if (isset($_SESSION['user'])) {
        echo "<form action='controllers/addresponse.php' method='post'>";
        echo "<textarea name='response' rows='4' cols='50' required></textarea><br>";
        echo "<input type='hidden' name='question_id' value='$question_id'>";
        echo "<input type='submit' value='Envoyer'>";
        echo "</form>";
    }
} else {
   
    header("Location: home.php");
    exit();
}


