<?php
include_once ("../models/db.php");
include_once("../controller/auth.php");
$questions=getQuetions();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
</head>
<body>

<?php if (isset($_SESSION["user"])): ?>
        <h3>Post a New Question :</h3>
        <form action="question.php" method="post">
            <div class="form-row">
                <div class="form-group col-md-6">
                <input type="text" class="form-control" name="question" placeholder="votre question">
                <button type="submit" class="btn btn-primary">Envoyer</button>
            </div>
</form>
    <?php endif; ?>
<pre>
<div class="form-row">
<div class="form-group col-md-6">
    <?php foreach($questions as $quest): ?>
        <div>
        <p><?php echo $quest->date;  
        echo getUsersByID($quest->user_id)->email;
        ?></p>
        <div class="question"><?php echo $quest->question ; ?>
        </div>
        <a href="responses.php?question_id=<?php echo $quest->id; ?>">Réponses</a>
        </div>
        <?php endforeach; ?>
</div>
</div>
</pre>


        </body>
</html>