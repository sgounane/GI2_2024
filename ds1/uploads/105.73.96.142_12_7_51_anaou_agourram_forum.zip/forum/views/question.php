<?php
session_start();
include_once ("../models/db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $newQuestion = $_POST["question"];
    

    if (!empty($newQuestion)) {
        $query = $db->prepare("INSERT INTO questions (user_id, question, date) VALUES (:user_id, :question, NOW())");
        //$query->execute(["user_id" => $userId, "question" => $newQuestion,]);

        exit();
    }
}