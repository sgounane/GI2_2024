<?php
session_start();
include_once("../models/db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["submit"])) {
    $nom=$_POST["nom"];
    $email = $_POST["email"];
    $password1 = $_POST["password1"];
    $password2 = $_POST["password2"];

    if($password1==$password2){
        $hashedPassword = password_hash($password1,PASSWORD_DEFAULT);
        $req = adduser($nom, $email, $hashedPassword);
        if ($req) {
            $_SESSION["passError"]="";
            header("Location: ../views/login.php");
        }
    }else{
        $_SESSION["passError"]="mdp doit etre le meme ! ";
        header("Location: ../views/register.php");  
    }
}


?>