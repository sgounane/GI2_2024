<?php
session_start();
include_once("../models/db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["submit"])) {
    $email = $_POST["email"];
    $password = $_POST["password"];

    $user = getUserByEmail($email);
    if($user){
        $hashedpswrd = $user->password;
        if(password_verify($password, $hashedpswrd)){
            $_SESSION["user"] =["email" => $user->email, "nom" => $user->nom];
            header("Location:../views/home.php");
            
        }else {
            $_SESSION["loginError"]="mdp incorrect";
            header("Location:../views/login.php");
        }
    }else{
        $_SESSION["mailError"]="email incorrect";
        header("Location:../views/login.php");
    }
}
?>