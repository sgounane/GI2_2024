<?php

function connect(){
    try {
        $db = new PDO('mysql:host=localhost;dbname=forum', 'root', '');
        return $db;
    }catch(PDOException $e){
            echo $e->getMessage();
            die();
    }

}
$db=connect();

function adduser($nom,$email,$password){
    global $db;
        $req=$db->prepare("INSERT INTO users(nom, email, password) VALUES(:t, :p, :i)");
        $req->execute(["t"=>$nom, "p"=>$email, "i"=>$password]);

    return $req;
}

//adduser("user1","user1@gmail.com","123");

function getUserByEmail($email){
    global $db;
        $req=$db->prepare("SELECT * FROM users WHERE email = :email");
        $req->execute(["email"=>$email]);
        $user=$req->fetch(PDO::FETCH_OBJ);
    return $user;
}

function getQuestions(){
    global $db;
        $req=$db->prepare("SELECT * FROM questions");
        $req->execute();
        $questions=$req->fetchAll(PDO::FETCH_OBJ);
    return $questions;
}
function getReponses($question_id){
    global $db;
        $req=$db->prepare("SELECT * FROM reponses where question_id =:qid ");
        $req->execute(["qid"=>$question_id]);
        $reponses=$req->fetchAll(PDO::FETCH_OBJ);
    return $reponses;
}

function addQuestion($user_id,$question){
    global $db;
    $currentDate = date('Y-m-d H:i:s');
        $req=$db->prepare("INSERT INTO questions(user_id, question, date) VALUES(:t, :p, :i)");
        $req->execute(["t"=>$user_id, "p"=>$question, "i"=>$currentDate]);

    return $req;
}

function addReponse($user_id,$question_id,$response){
    global $db;
    $currentDate = date('Y-m-d H:i:s');
        $req=$db->prepare("INSERT INTO reponses(user_id,question_id,response,date) VALUES(:t, :p, :i, :c)");
        $req->execute(["t"=>$user_id, "p"=>$question_id, "i"=>$response, "c"=>$currentDate]);
    return $req;
}
?>