<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <title>login</title>
</head>
<body style="padding:100px">
    <div class="container">
    <form style="width:500px; margin:auto;" action="../controllers/auth.php" method="POST">
    <h1 style="text-align:center">Login</h1>
  <div class="form-group">
    <label for="exampleInputEmail1">Email address</label>
    <input type="email" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" required>
    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
    <?php if(isset($_SESSION["mailError"])) {
        echo "<p style='color:red' >".$_SESSION['mailError']."</p>";
        unset($_SESSION["mailError"]);
    } ?>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">password</label>
    <input type="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="Password" required>
    <?php if(isset($_SESSION["loginError"])) {
        echo "<p style='color:red' >".$_SESSION['loginError']."</p>";
        unset($_SESSION["loginError"]);
    } ?>
  </div>
  <br>
  <button type="submit" name="submit" class="btn btn-primary">Submit</button>
  <br>
  <br>
  <a href="register.php">Si vous n etes pas enretgistere clickez ici</a>
</form>
    </div>
</body>
</html>