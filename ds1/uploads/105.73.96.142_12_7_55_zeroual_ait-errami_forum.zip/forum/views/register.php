<?php 
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <title>Register</title>
</head>
<body style="padding:100px">
    <div class="container">
    <form style="width:500px; margin:auto;" action="../controllers/adduser.php" method="POST">
    <h1 style="text-align:center"> Enregistrement</h1>
    <div class="form-group">
    <label for="nom">Nom</label>
    <input type="text" class="form-control" name="nom" id="nom" aria-describedby="emailHelp" placeholder="Enter name" required>
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Email address</label>
    <input type="email" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" required>
    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <input type="password" name="password1" class="form-control" id="exampleInputPassword1" placeholder="Password" required>
    <?php if(isset($_SESSION["passError"])) {
        echo "<p style='color:red' >".$_SESSION['passError']."</p>";
        unset($_SESSION["passError"]);
    } ?>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Confirmer password</label>
    <input type="password" name="password2" class="form-control" id="exampleInputPassword1" placeholder="Password" required>
  </div>
  <br>
  <button type="submit" name="submit" class="btn btn-primary">Submit</button>
</form>
    </div>
</body>
</html>