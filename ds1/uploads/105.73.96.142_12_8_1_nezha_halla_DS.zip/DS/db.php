<?php
$conn = mysqli_connect("localhost","root","","forum");
if ($conn->connect_error) {
    die("La connexion a échoué : " . $conn->connect_error);
}
?>


