<?php
session_start();
include 'db.php'; // Inclure le fichier de connexion à la base de données

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_SESSION['user_id'])) {
        $user_id = $_SESSION['user_id'];
        $question_id = $_POST['question_id'];
        $reponse = $_POST['reponse'];
        $date = date("Y-m-d H:i:s");

        $stmt = $conn->prepare("INSERT INTO reponses (user_id, question_id, reponse, date) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("iiss", $user_id, $question_id, $reponse, $date);

        if ($stmt->execute()) {
            // Réponse enregistrée avec succès
            echo "Réponse enregistrée avec succès.";
        } else {
            // Erreur lors de l'enregistrement de la réponse
            echo "Erreur lors de l'enregistrement de la réponse : " . $conn->error;
        }

        $stmt->close();
    } else {
        // Rediriger vers la page de connexion si l'utilisateur n'est pas connecté
        header("Location: login.php");
        exit;
    }
} else {
    // Rediriger vers une autre page si la méthode de requête n'est pas POST
    header("Location: autre_page.php");
    exit;
}
?>
