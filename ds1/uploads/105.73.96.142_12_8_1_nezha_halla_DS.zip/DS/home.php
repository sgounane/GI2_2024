<?php
session_start();

// Vérification de la session d'utilisateur
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

include 'db.php'; // Inclure le fichier de connexion à la base de données

// Traitement du formulaire pour ajouter une nouvelle question
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['new_question']) && !empty(trim($_POST['new_question']))) {
        $user_id = $_SESSION['user_id'];
        $question = $_POST['new_question'];
        $date = date("Y-m-d H:i:s");

        $stmt = $conn->prepare("INSERT INTO questions (user_id, question, date) VALUES (?, ?, ?)");
        $stmt->bind_param("iss", $user_id, $question, $date);
        $stmt->execute();
        $stmt->close();
    }
}

// Récupération des questions depuis la base de données
$stmt = $conn->prepare("SELECT id, user_id, question, date FROM questions ORDER BY date DESC");
$stmt->execute();
$result = $stmt->get_result();
$questions = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Accueil</title>
    <style>
        /* Reset de la marge et du padding pour le corps de la page */
body {
  margin: 0;
  padding: 0;
  font-family: Arial, sans-serif;
  background-color: #f4f4f4;
  display: flex;
  flex-direction: column;
  align-items: center;
}

/* Style pour le titre h2 */
h2 {
  margin-top: 20px;
  text-align: center;
}

/* Style pour le formulaire de saisie de nouvelle question */
form {
  margin-top: 20px;
  display: flex;
  justify-content: center;
  align-items: center;
}

form input[type="text"] {
  padding: 10px;
  margin-right: 10px;
  border-radius: 5px;
  border: 1px solid #ccc;
}

form button {
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  background-color: #007bff;
  color: #fff;
  cursor: pointer;
}

form button:hover {
  background-color: #0056b3;
}

/* Style pour la liste des questions */
ul {
  list-style: none;
  padding: 0;
  margin-top: 20px;
  width: 80%;
}

li {
  margin-bottom: 10px;
  padding: 10px;
  border-radius: 5px;
  background-color: #fff;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

/* Style pour le message si aucune question n'est trouvée */
p {
  margin-top: 20px;
  text-align: center;
  font-style: italic;
  color: #888;
}

    </style>
</head>
<body>
    <h2>Bienvenue sur la page d'accueil</h2>
    
    <!-- nouveau question pour user  -->
    <form action="home.php" method="post">
        <input type="text" name="new_question" placeholder="Posez une nouvelle question">
        <button type="submit">Envoyer</button>
    </form>

    <!-- Affichage des questions -->
<?php if (!empty($questions)) { ?>
    <h3>Questions :</h3>
    <ul>
        <?php foreach ($questions as $q) { ?>
            <li>
                <?php
                $userId = $q['user_id'];
                $userQuery = $conn->prepare("SELECT nom, email FROM users WHERE id = ?");
                $userQuery->bind_param("i", $userId);
                $userQuery->execute();
                $userResult = $userQuery->get_result();
                $user = $userResult->fetch_assoc();
                $userQuery->close();
                ?>
                <strong><?php echo htmlspecialchars($user['nom']); ?>:</strong>
                <?php echo htmlspecialchars($q['question']); ?>
                (Date : <?php echo htmlspecialchars($q['date']); ?>)
                <button onclick="toggleForm(<?php echo $q['id']; ?>)">Répondre</button>
                <!-- Formulaire de réponse (initialement caché) -->
                <div id="form-<?php echo $q['id']; ?>" style="display: none;">
                    <form action="db2.php" method="post">
                        <input type="hidden" name="question_id" value="<?php echo $q['id']; ?>">
                        <textarea name="reponse" placeholder="Votre réponse" required></textarea>
                        <button type="submit">Envoyer</button>

                    </form>
                </div>
                <a href="rep.php?id=<?php echo $q['id']; ?>">Voir les réponses</a>
            </li>
        <?php } ?>
    </ul>
<?php } else { ?>
    <p>Aucune question trouvée.</p>
<?php } ?>
<script>
    function toggleForm(questionId) {
        var form = document.getElementById('form-' + questionId);
        if (form.style.display === 'none') {
            form.style.display = 'block';
        } else {
            form.style.display = 'none';
        }
    }
</script>
</body>
</html>
