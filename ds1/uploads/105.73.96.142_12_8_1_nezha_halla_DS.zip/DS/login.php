
<?php
include 'db.php'; // Inclure le fichier de connexion à la base de données

session_start(); // Démarrer la session

// Vérifier si l'utilisateur est déjà connecté
if (isset($_SESSION['user_id'])) {
    header("Location: home.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, email, password FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        header("Location: home.php");
        exit;
    } else {
        $error_message = "Identifiants incorrects. Veuillez réessayer.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion</title>
    <style>
        /* Reset de la marge et du padding pour le corps de la page */
body {
  margin: 0;
  padding: 0;
  font-family: Arial, sans-serif;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background-color: #f4f4f4;
}

/* Style du formulaire */
h2 {
  text-align: center;
}

form {
  background-color: #fff;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  width: 300px;
  position: absolute;
  width: 500px;
  height: 300px;
}

/* Style des groupes de formulaires (email, password) */
div {
  margin-bottom: 15px;
}

/* Style des étiquettes */
label {
  display: block;
  margin-bottom: 6px;
}

/* Style des champs de formulaire */
input[type="email"],
input[type="password"] {
  width: calc(100% - 22px);
  padding: 8px;
  border-radius: 4px;
  border: 1px solid #ccc;
}

/* Style du bouton de connexion */
button {
  padding: 10px 20px;
  border: none;
  border-radius: 4px;
  background-color: #007bff;
  color: #fff;
  cursor: pointer;
  font-size: 16px;
}

/* Style du bouton de connexion au survol */
button:hover {
  background-color: #0056b3;
}

/* Style pour le message d'erreur */
p.error-message {
  color: red;
  margin-top: 10px;
  font-size: 14px;
}
p{
    position: inherit;
    top: 800px;
    left: 40%;
}
/* Style pour le lien de création de compte */
p a {
  text-decoration: none;
  color: #007bff;
}

p a:hover {
  text-decoration: underline;
}

    </style>
</head>
<body>
    
    <form action="login.php" method="post">
        <div>
            <label for="email">Email :</label>
            <input type="email" id="email" name="email" required>
        </div>
        <div>
            <label for="password">Mot de passe :</label>
            <input type="password" id="password" name="password" required>
        </div>
        <?php if(isset($error_message)) { ?>
            <p><?php echo $error_message; ?></p>
        <?php } ?>
        <button type="submit">Se connecter</button>
    </form>
    <p>Vous n'avez pas de compte ? <a href="registrer.php">Créer un compte</a></p>
</body>
</html>
