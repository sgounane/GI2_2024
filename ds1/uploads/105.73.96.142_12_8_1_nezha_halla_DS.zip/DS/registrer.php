<?php
include 'db.php'; // Inclure le fichier de connexion à la base de données

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nom = $_POST['nom'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirm-password'];

    if ($password === $confirmPassword) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        $stmt = $conn->prepare("INSERT INTO users (nom, email, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $nom, $email, $hashedPassword);

        if ($stmt->execute()) {
            echo "Utilisateur enregistré avec succès.";
        } else {
            echo "Erreur lors de l'enregistrement de l'utilisateur : " . $conn->error;
        }

        $stmt->close();
    } else {
        echo "Les mots de passe ne correspondent pas.";
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Enregistrement</title>
  <style>/* Reset de la marge et du padding pour le corps de la page */
body {
  margin: 0;
  padding: 0;
  font-family: Arial, sans-serif;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background-color: #f4f4f4;
}

/* Style du formulaire */
form {
  background-color: #fff;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  width: 300px;
  position: absolute;
  width: 700px;
  height: 500px;
}

/* Style des groupes de formulaires (nom, email, etc.) */
div {
  margin-bottom: 15px;
}

/* Style des étiquettes */
label {
  display: block;
  margin-bottom: 6px;
}

/* Style des champs de formulaire */
input[type="text"],
input[type="email"],
input[type="password"] {
  width: calc(100% - 22px);
  padding: 8px;
  border-radius: 4px;
  border: 1px solid #ccc;
}

/* Style du bouton de soumission */
button {
  padding: 10px 20px;
  border: none;
  border-radius: 4px;
  background-color: #007bff;
  color: #fff;
  cursor: pointer;
  font-size: 16px;
}

/* Style du bouton de soumission au survol */
button:hover {
  background-color: #0056b3;
}
</style>
</head>
<body>
  
  <<form action="registrer.php" method="POST">
    <div>
      <label for="nom">Nom :</label>
      <input type="text" id="nom" name="nom" required>
    </div>
    <div>
      <label for="email">Email :</label>
      <input type="email" id="email" name="email" required>
    </div>
    <div>
      <label for="password">Mot de passe :</label>
      <input type="password" id="password" name="password" required>
    </div>
    <div>
      <label for="confirm-password">Confirmez le mot de passe :</label>
      <input type="password" id="confirm-password" name="confirm-password" required>
    </div>
    <button type="submit">S'inscrire</button>
  </form>
</body>
</html>
