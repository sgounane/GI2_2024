<?php
include 'db.php'; // Inclure le fichier de connexion à la base de données

// Vérifier si l'ID de la question est passé en paramètre dans l'URL
if (isset($_GET['id']) && !empty(trim($_GET['id']))) {
    $question_id = $_GET['id'];

    // Récupérer la question spécifique
    $stmt = $conn->prepare("SELECT * FROM questions WHERE id = ?");
    $stmt->bind_param("i", $question_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $question = $result->fetch_assoc();
    $stmt->close();

    // Récupérer les réponses associées à la question
    $reponsesQuery = $conn->prepare("SELECT * FROM reponses WHERE question_id = ?");
    $reponsesQuery->bind_param("i", $question_id);
    $reponsesQuery->execute();
    $reponsesResult = $reponsesQuery->get_result();
    $reponses = $reponsesResult->fetch_all(MYSQLI_ASSOC);
    $reponsesQuery->close();
} else {
    // Rediriger vers une autre page si l'ID de la question est absent
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Réponses à la question</title>
    <style>body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 20px;
}

h2 {
    color: #333;
    font-size: 24px;
    margin-bottom: 15px;
}

p {
    color: #444;
    font-size: 18px;
}

ul {
    list-style: none;
    padding-left: 0;
}

li {
    color: #555;
    font-size: 16px;
    margin-bottom: 8px;
    border: 1px solid black;
}
</style>
</head>
<body>
    <?php if (!empty($question)) { ?>
        <h2>Question :</h2>
        <p><strong></strong> <?php echo htmlspecialchars($question['question']); ?></p>

        
        <?php if (!empty($reponses)) { ?>
            <h3>Réponses :</h3>
            <ul>
                <?php foreach ($reponses as $reponse) { ?>
                    <li><?php echo htmlspecialchars($reponse['reponse']); ?></li>
                <?php } ?>
            </ul>
        <?php } else { ?>
            <p>Aucune réponse trouvée pour cette question.</p>
        <?php } ?>
    <?php } else { ?>
        <p>La question spécifiée n'a pas été trouvée.</p>
    <?php } ?>
</body>
</html>