<?php
require_once("../models/db.php");
session_start();



    if (isset($_POST['registre'])) {
        if ($_POST['password'] !== $_POST['conf_password']) {
           header('location:../views/registre.php?ereur=Password_Not_matched');
        } else {
            $email = $_POST['email'];
            $sql = $conn->prepare('SELECT * FROM users WHERE Email = :Email');
            $sql->execute(array(':Email' => $email));

            $row = $sql->fetch(PDO::FETCH_ASSOC);
            
            if (!empty($row)) {
                header('location:../views/registre.php?ereur=already_existe');
            } else {
                $email=$_POST['email'];
                $name = $_POST['name'];
                $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
               adduser( $name,$email, $password);
                header('location:../views/login.php');
            }

        }
    
}


?>