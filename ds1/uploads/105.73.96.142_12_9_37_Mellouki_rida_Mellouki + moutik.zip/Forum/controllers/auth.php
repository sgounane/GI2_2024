<?php
header("../views/login.php");

if (isset($_POST['submit'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];
    require_once("../models/db.php");
    $row = getUserByEmail($email);
    if (!$row) {
        header("location:../views/login.php?ereur=user_not_found");
    } else {
        if (password_verify($password, $row['password'])) {
            session_start();
            $_SESSION['user'] = array(
                'nom' => $row['nom'],
                'email' => $row['email'],
                'id' => $row['id']
            );
            header('location: ../views/home.php');
        } else {
            echo '<script>alert("Mot de passe incorrect")</script>';
        }
    }


}

if(isset($GET['action'])&& $_GET['action']=="logout"){
    session_start();
    session_unset();
    session_destroy();
}
?>