<?php



$host = 'localhost';
$dbname = 'forum';
$user = 'root';
$pass = '';

try {
    $conn = new PDO('mysql:host=' . $host . ';dbname=' . $dbname . ';', $user, $pass);
} catch (PDOException $e) {
    echo 'Ereur : ' . $e->getMessage();
}


function adduser($nom, $email, $password)
{

    global $conn;

    $sql = $conn->prepare('INSERT INTO users (nom , email , password) VALUES (:nom , :email , :password)');
    $sql->execute(
        array(
            ':nom' => $nom,
            ':email' => $email,
            ':password' => $password
        )
    );
}

function getUserByEmail($email)
{
    global $conn;
    try {
        $sql = "SELECT * FROM Users WHERE email = :email";
        $stmt = $conn->prepare($sql);
        $stmt->execute(array(':email' => $email));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($row) {
            return $row;
        } else {
            return null; // if usr not found
        }
    } catch (PDOException $e) {
        error_log("Error: " . $e->getMessage());
        return null;
    }
}

function getUserById($id)
{
    global $conn;
    try {
        $sql = "SELECT * FROM Users WHERE id = :id";
        $stmt = $conn->prepare($sql);
        $stmt->execute(array(':id' => $id));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($row) {
            return $row;
        } else {
            return null; // if usr not found
        }
    } catch (PDOException $e) {
        error_log("Error: " . $e->getMessage());
        return null;
    }
}
function getReponses($question_id)
{
    global $conn;
    try {
        $sql = "SELECT * FROM Reponses WHERE question_id = :qid ";
        $stmt = $conn->prepare($sql);
        $stmt->execute(
            array(
                ':qid' => $question_id,
            )
        );
        $row = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if ($row) {
            return $row;
        } else {
            return null;
        }
    } catch (PDOException $e) {
        error_log("Error: " . $e->getMessage());
        return null;

    }
}
function getQuestions()
{
    global $conn;
    try {
        $sql = "SELECT * FROM Questions ORDER BY date DESC";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if ($row) {
            return $row;
        } else {
            return null;
        }
    } catch (PDOException $e) {
        error_log("Error: " . $e->getMessage());
        return null;
    }
}

function addQuestion($user_Id, $question)
{
    global $conn;
    try {
            $date = date("Y-m-d");
            $stmt = $conn->prepare("INSERT INTO questions(user_id, question, date) VALUES (?, ?, ?)");
            $stmt->execute([$user_Id, $question, $date]);
    } catch (PDOException $e) {
        error_log("ereur". $e->getMessage());
        
    }}
function addresponse($user_id,$questin_id , $response){
    global $conn;
try {
    $date = date("Y-m-d");
    $sql = $conn->prepare('INSERT INTO reponses(user_id, question_id , response, date) VALUES (:user_id , :question_id , :response ,:date) ');
    $sql->execute(array(
            ':user_id' => $user_id,
            ':question_id' => $questin_id,
            ':response' => $response ,
                'date' =>$date));


}catch (PDOException $e) {
    error_log("ereur". $e->getMessage());
}
}

?>