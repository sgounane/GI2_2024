<?php
session_start();
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <title>Question et réponse</title>
    <!-- Bootstrap CDN -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 class="text-center">Question et réponse</h1>
                <?php
                if (isset($_POST['submit'])) {
                    require_once "../models/db.php";
                    addQuestion($_SESSION['user']['id'], $_POST['question']);
                }



                ?>
                <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" class="form-inline my-4">
                    <input type="text" class="form-control mr-2" placeholder="Votre question ici ...." name="question">
                    <button type="submit" class="btn btn-primary" name="submit">Envoyer</button>
                </form>
                <?php
                require_once "../models/db.php";
                $rows = getQuestions();
                if ($rows) {
                    foreach ($rows as $row) {
                        ?>
                        <div class="card mb-3">
                            <div class="card-body">
                                
                                    <p class="card-text"><small class="text-muted">
                                            <?= $row['date'] ?>
                                            <?= getUserById($row['User_Id'])['email'] ?>
                                        </small></p>
                                    <h5 class="card-title">
                                        <?= $row['question'] ?>
                                    </h5>
                                <form action="./question.php" method="post">
                                    <input type="hidden" name="question_id" value="<?= $value['id'] ?>">
                                    <input type="hidden" name="question" value="<?= $value['question'] ?>">
                                    <button type="submit" name="submit" class="btn btn-secondary">Réponses</button>
                                </form>
                            </div>
                        </div>
                    <?php }
                }


                ?>

            </div>
        </div>
    </div>
    </div>
</body>

</html>