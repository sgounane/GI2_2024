<?php 
session_start();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Question et réponse</title>
    <!-- Bootstrap CDN -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<?php 
                if(isset($_POST['submit'])){
                    require_once "../models/db.php";
                    addresponse($_SESSION['user']['id'],$_POST['question_id'],$_POST['question']);
                }

                

                ?>
    
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 class="text-center">Question et réponse</h1>
                    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" class="form-inline my-4">
                    <input type="text" class="form-control mr-2" placeholder="Votre reponse ici ...." name="reponse">
                    <button type="submit" class="btn btn-primary" name="submit">Envoyer</button>
                </form>
                <a href="#" class="btn btn-primary my-4">Retour aux questions</a>
                <?php 
                require_once("../models/db.php");
                if(isset($_POST['submit'])){
                    $rows = getReponses($_POST['question_id']);
                    foreach($rows as $row){
                        ?>
                                    <div class="card mb-3">
                    <div class="card-body">
                        <p class="card-text"><small class="text-muted"><?=$row['date']?> <?= getUserById($row['User_Id'])['email']?></small></p>
                        <h5 class="card-title"><?= $row['response']?></h5>
                    </div>
                </div>


<?php

                }
            }
                
                ?>
            </div>
        </div>
    </div>
</body>
</html>