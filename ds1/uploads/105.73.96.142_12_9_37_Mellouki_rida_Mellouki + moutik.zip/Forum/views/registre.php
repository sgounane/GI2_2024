<?php
if(isset($_GET['ereur'])){
    $ereur = $_GET['ereur'];
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

</head>

<body>

    <div class="container">
        <div class="row justify-content-center m-5">
            <div class="col-lg-6 form-container">
                <h2 class="mb-4">Register</h2>
                <?php if (!empty($ereur) && $ereur === 'Password_Not_matched'): ?>
                    <h5 class="text-danger">Password not matched</h5>
                <?php endif; ?>
                <?php if (!empty($ereur) && $ereur === 'already_existe'): ?>
                    <h5 class="text-danger">Email already existe</h5>
                <?php endif; ?>
                <form action="../controllers/adduser.php" method="post">
                    <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" class="form-control" id="name" name="name" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" class="form-control" id="email" name="email" required>

                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" class="form-control" id="password" name="password" required>

                    </div>
                    <div class="form-group">
                        <label for="conf_password">Confirme Password</label>
                        <input type="password" class="form-control" id="conf_password" name="conf_password" required>
                    </div>
                    <input type="submit" class="btn btn-primary" value="Registre" name="registre">
                </form>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>