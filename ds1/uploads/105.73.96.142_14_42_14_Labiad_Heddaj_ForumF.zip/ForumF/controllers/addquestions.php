<?php
session_start();
include_once('../models/db.php');
if(isset($_SESSION["user"])) {
    $email=$_SESSION["user"]['email'];
    $dateActuelle = date('Y-m-d H:i:s');
    $users=getUserByEmail($email);
    if(isset($_POST['envoyer'])){
        $question=$_POST['question'];
        if (isset($users->id)) {
            $userId = $users->id;
            addQuestion($userId,$question,  $dateActuelle);
        } else {
            echo "L'utilisateur n'a pas de propriété 'id'.";
        }
    }
   
    }

?>