<?php
include_once('../models/db.php');
if (isset($_POST['register'])){
$nom=$_POST['nom'];
$email=$_POST['email'];
$pwd=$_POST['pwd'];
$cpwd=$_POST['cpwd'];
if($pwd != $cpwd){
    echo "password not matched";
}
else{
    $hash=password_hash($pwd,PASSWORD_DEFAULT);
    adduser($nom,$email,$hash);
    header('location:../views/login.php');
}


}



?>