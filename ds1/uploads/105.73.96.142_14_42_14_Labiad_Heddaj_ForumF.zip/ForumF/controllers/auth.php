<?php
session_start();
include_once('../models/db.php');

if(isset($_POST['login'])){

    $email=$_POST['email'];
    $pwd=$_POST['pwd'];
    $error = array();

    if(!empty($email) && !empty($pwd)){
    $users=getUserByEmail($email);
    if ($users) {
        $id=$users->id;
        $nom = $users->nom;
        $email = $users->email;
        $password = $users->password;

    if (password_verify($pwd, $password)) {
        $_SESSION["user"]=["nom"=>$users->nom,"email"=>$users->email];
        header('location:../views/home.php');
    } else {
        $_SESSION["error"] = 'password est incorrecte!!';
        exit();
        
    }
    
    

}}else {
    $_SESSION["error"] = 'remplissez les deux champs';
        exit();
    }
}

    

?>