<?php
$base = "";
include_once("models/db.php");

$request_uri_parts = explode('?', $_SERVER["REQUEST_URI"], 2);
$path = $request_uri_parts[0];

header("Content-type: application/json");

        $questionId = isset($_GET['question_id']) ? $_GET['question_id'] : null;
        if ($questionId !== null) {
            $responses = getResponses($questionId);
            $responsesWithUsers = array_map(function ($response) {
                $user = getUserById($response->user_id);
                $response->user = $user;
                return $response;
            }, $responses);
            echo json_encode(['responses' => $responsesWithUsers]);
        } else {
            http_response_code(400); // Bad Request
            echo json_encode(['error' => 'Missing question ID']);
        }
        echo json_encode(['error' => 'Not found']);

?>