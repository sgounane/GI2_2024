<?php
session_start();
include_once("../models/db.php");
if (isset($_POST["addQuestion"])) {
    $questionText = $_POST["questionText"];
    $userId = getUserIdByEmail($_SESSION["user"]); 
    addQuestion($userId, $questionText);
}
$user = $_SESSION["user"]; 
$questions = getQuestions();



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>home</title>
    <link rel="stylesheet" href="../views/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }

        .navbar {
            background-color: #e3f2fd;
            padding: 10px;
            margin-bottom: 20px;
        }

        .con {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .question-list {
            background-color: #fff;
            border-radius: 8px;
            padding: 20px;
        }

        .question-item {
            border: 1px solid #ccc;
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 8px;
        }

        .question-item p {
            margin-bottom: 10px;
        }

        .btn-primary {
            background-color: #007bff;
            color: #fff;
            padding: 8px 16px;
            text-decoration: none;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    
<div class="row justify-content-center container">
            
            <div class="col-md-8">
                <?php
                if (isset($_SESSION["user"])) { ?>
                    <nav class="navbar navbar-expand-lg navbar-light bg-light">
                        <a class="nav-link" href="../controllers/logout.php">Logout</a>
                    </nav>
                <?php } else { ?>
                    <nav class="navbar navbar-expand-lg navbar-light bg-light navbar">
                        <a class="nav-link" href="login.php">Login</a>
                    </nav>
                <?php } ?>
   <div class="con">
   <form action="" method="POST">
        <input type="text" name="questionText" placeholder="votre question ici ..."><br>
        <input type="submit" value="envoyer"name="addQuestion">
    </form>
    
    </div>
    <div class="question-list">
                <?php foreach ($questions as $question) { ?>
                    <div class="question-item">
                        <p><?php echo $question->question; ?></p>
                        <a href="../views/question.php?id=<?php echo $question->id; ?>" class="btn btn-primary">Répondre</a>
                    </div>
                <?php } ?>
            </div>


            <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="../public/questions.js"></script>
    <script src="../public/reponse.js"></script>
    
</body>
</html>