<?php
session_start();
include_once("../models/db.php");

if (isset($_GET["id"])) {
    $questionId = $_GET["id"];
    $question = getQuestionById($questionId);

    if ($question !== null) {
        $user = getUserById($question->user_id);
        $responses = getResponses($questionId);

        if (isset($_POST["addResponse"])) {
            $responseText = $_POST["responseText"];
            $userId = getUserIdByEmail($_SESSION["user"]);
            addResponse($userId, $questionId, $responseText);
            $responses = getResponses($questionId);
        }
    } else {
        echo "Error: question non trouvé.";
        exit;
    }
} else {
    echo "Error: question id not provided.";
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Question</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
            <?php if ($question !== null): ?>
    <h2 class="mb-4">Question: <?= $question->question ?></h2>
    <p>Date: <?= (new DateTime($question->date))->format('F j, Y, g:i a') ?></p>
    
<?php else: ?>
    <p>Error: question non trouvé.</p>
<?php endif; ?>

            <h2 class="mb-4">Question: <?= $question->question ?></h2>
                <p>Date: <?= (new DateTime($question->date))->format('F j, Y, g:i a') ?></p>
                
                
                <?php if (isset($_SESSION["user"])) { ?>
                    <h4>ajouter une reponse</h4>
                    <form method="post" >
                        <input type="hidden" name="addResponse" value="1">
                        <input type="hidden" name="questionId" value="<?= $questionId ?>">
                        <div class="mb-3">
                            <label for="responseText" class="form-label">votre reponse:</label>
                            <input type="text" class="form-control" name="responseText" id="responseText" required>
                        </div>
                        <button type="submit" class="btn btn-primary" name="addResponse">Envoyer réponse</button>
                    </form><br>
                    <?php } ?>
                    <a href="home.php" class="btn btn-primary" name="addResponse">Retour</a>
                    <br>
                <h3>les Responses</h3>

                
                
    <?php if (!empty($responses) && (is_array($responses) || is_object($responses))) { ?>
    <ul id="responsesList" class="list-group mt-4">
        <?php foreach ($responses as $response) { ?>
            <li class="list-group-item">
                <strong><?= $response->user_id ?></strong>: <?= $response->response ?>
            </li>
        <?php } ?>
    </ul>
<?php } else { ?>
    <p>No responses available.</p>
<?php } ?>


                <?php if (isset($_SESSION["user"])) :
                ?>

                <?php endif; ?>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="../public/reponse.js"></script>
    <script>
        var questionId = <?= $questionId ?>;
    </script>
</body>

</html>