<?php
include_once("../models/db.php");
session_start();

if(isset($_SESSION["user"])){
    $qstcontent = $_POST["question"];
   // echo $_POST["question"] ."<br>";
   // var_dump($_SESSION["user"]);
    $user = getUserByEmail($_SESSION["user"]["email"]);

    addQuestion($user->id,$qstcontent);
    header("Location:../views/home.php");
}
else{
    header("Location:../views/login.php");
}
?>