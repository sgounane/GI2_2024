<?php
include_once("../models/db.php");
session_start();

if(isset($_SESSION["user"])){
    $idqst=$_POST["idqst"];
    $repcontent = $_POST["reponse"];
   // echo $_POST["reponse"] ."<br>";
   // echo $idqst;

    $user = getUserByEmail($_SESSION["user"]["email"]);

    addReponse($user->id,$idqst,$repcontent);
    header("Location:../views/question.php?id=".$idqst);
}
else{
    header("Location:../views/login.php");
}
?>