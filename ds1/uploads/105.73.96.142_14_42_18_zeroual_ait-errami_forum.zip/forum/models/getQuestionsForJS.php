<?php

include_once("db.php");

header("Content-type: application/json");

$qsts = getQuestions();

$qstsWithUsers=array_map(function($qst){
    $user=getUserById($qst->user_id);
    $qst->user = $user ;
    return $qst;
},$qsts);

$qstsWithUsers = json_encode($qstsWithUsers);

echo $qstsWithUsers ;
?>