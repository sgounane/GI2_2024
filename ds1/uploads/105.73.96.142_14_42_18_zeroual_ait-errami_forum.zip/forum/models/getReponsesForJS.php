<?php
session_start();
include_once("db.php");

header("Content-type: application/json");

$idqst = $_GET["id"];

$reponses = getReponses($idqst);

$repsWithUsers=array_map(function($rep){
    $user=getUserById($rep->user_id);
    $rep->user = $user ;
    return $rep;
},$reponses);

$repsWithUsers = json_encode($repsWithUsers);

echo $repsWithUsers ;
?>