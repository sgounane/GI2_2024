let qstsContainer = document.querySelector(".QstsContainer");


function displayQuestions (){
    
let req = new XMLHttpRequest();

req.open("GET","../models/getQuestionsForJS.php");

req.onreadystatechange=()=>{
    qstsContainer.innerHTML = "";

    if(req.status==200 && req.readyState==4){
        questions = JSON.parse(req.response);
       // console.log(questions); /* array indexe of objects */

        questions.forEach(qst => {
            
            qstsContainer.innerHTML += `
            <div class="qstcontainer">
                <span >${qst.date}</span>
                <span > ${qst.user.email}</span>
                <div class="question"  > ${qst.question}</div>
                <br>
                <a href="question.php?id=${qst.id}">reponses</a>
            </div> `;
        });
    }
}

req.send();

}

displayQuestions();

setInterval(displayQuestions,30000);


