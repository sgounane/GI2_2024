let qstsContainer = document.querySelector(".QstsContainer");


function displayReponses (){
    
let req = new XMLHttpRequest();

req.open("GET",`../models/getReponsesForJS.php?id=${qstID}`);

req.onreadystatechange=()=>{
    qstsContainer.innerHTML = "";

    if(req.status==200 && req.readyState==4){
        reps = JSON.parse(req.response);

        reps.forEach(rep => {

            qstsContainer.innerHTML += `
            <div class="qstcontainer">
                <span >${rep.date}</span>
                <span > ${rep.user.email}</span>
                <div class="question"  > ${rep.response}</div>
                <br>
            </div> `;
        });
    }
}

req.send();

}

displayReponses();

setInterval(displayReponses,30000);


