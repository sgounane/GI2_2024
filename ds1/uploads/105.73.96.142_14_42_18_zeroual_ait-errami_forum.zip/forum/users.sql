-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : dim. 26 nov. 2023 à 15:24
-- Version du serveur : 10.4.27-MariaDB
-- Version de PHP : 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `forum`
--

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `nom`, `email`, `password`) VALUES
(2, 'usertest', 'usertest@gmail.com', '$2y$10$tIedHtVNF03W1cT/8j.r1OKyLFK.CcB/22eWZP98VupBVoDYY7Djy'),
(3, 'aicha', 'a@gmail.com', '$2y$10$bwx5aABjm/VRGStLIcIwZuWQKPsDK2xprdyXz77w7b8PiG/XcanDy'),
(6, 'zineb', 'zineb@gmail.com', '$2y$10$CbmkDwiSypmOeukWCwyn7O7KOGEepv.rTE4qKRRyLbmhQ29Ywl/PO'),
(7, 'user3', 'user3.@gmail.com', '$2y$10$0Ze7GeVgG7dmQp7ZFaOO3.Jddee3hynJ2MtDnLXNRJhKQxjJSHO/C'),
(8, 'zineb', 'zineb01@gmail.com', '$2y$10$w427vVjrG8r76R5bTdf0tOGJ.uwgWRGTT4TQN.4JN0FLUnrBlcBVa');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_email` (`email`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
