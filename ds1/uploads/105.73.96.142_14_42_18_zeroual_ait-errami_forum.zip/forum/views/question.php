<?php
include_once("../models/db.php");
session_start();

$idqst=$_GET["id"];
$qst=getQuestionByID($idqst);

$responses = getReponses($idqst);
//var_dump($responses);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <title>Home</title>
</head>
<body>
    <nav>
    <?php if(isset($_SESSION["user"])):?>
                <a href="../controllers/logout.php">Logout</a>
            <?php else:?>
                <a href="login.php">Login</a>
            <?php endif ?>
    </nav>

    <div class="container" >

         <p><?= $qst->question ?></p>
         <br>
        <form action="../controllers/addReponse.php" method="POST">
         <div class="form-group">
             <input type="text" name="reponse" class="form-control" placeholder="Votre reponse ici " required>
             <br>
             <input type="hidden" name="idqst" value="<?= $idqst ?>">
             <button type="submit" name="submit" class="btn btn-primary" >Submit</button>
        </div>
        </form>

        
        <br>
        <br>
        
        <div class="QstsContainer" class="dropdown-menu">
           
        </div>
    </div>

    <script>
        let qstID = <?= $idqst ?> ;
    </script>
    <script src="../public/reponses.js"></script>
</body>
</html>