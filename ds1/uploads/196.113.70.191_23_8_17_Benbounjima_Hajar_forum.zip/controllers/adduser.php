<?php
include_once("../models/db.php");
session_start();

$errors = array();

if (isset($_POST['register'])) {
    $name = $_POST['nom'];
    $name = filter_var($name, FILTER_SANITIZE_STRING);
    $email = $_POST['email'];
    $email = filter_var($email, FILTER_SANITIZE_STRING);
    $pass = $_POST['password'];
    $pass = filter_var($pass, FILTER_SANITIZE_STRING);
    $cpass = $_POST['cpassword'];
    $cpass = filter_var($cpass, FILTER_SANITIZE_STRING);

    $select_user = $db->prepare("SELECT * FROM `users` WHERE email = :email");
    $select_user->execute(["email" => $email]);
    $select_user->execute(["email" => $email]);
    $rowCount = $select_user->rowCount();
    
    if ($rowCount > 0) {
        $errors[] = 'Email already exists';
    } else {
        if ($pass != $cpass) {
            $errors[] = 'Passwords do not match';
        } else {
            $hash = password_hash($pass, PASSWORD_BCRYPT);
            adduser($name, $email, $hash);
            header("Location: ../views/login.php");
            exit(); 
        }
    }


    $_SESSION['errors'] = $errors;

    header("Location: ../views/register.php");
    exit();
}
?>
