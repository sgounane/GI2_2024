<?php

function connect(){
    try {
        $db = new PDO('mysql:host=localhost;dbname=forum', 'root', '');
        return $db;
    } catch(PDOException $e){
        echo $e->getMessage();
        die();
    }
}
$db = connect();

function adduser($nom,$email,$password){
    global $db;
    $hash = password_hash($password, PASSWORD_BCRYPT);
    $req = $db->prepare("INSERT INTO users (nom,email,password) VALUES (:nom,:email,:password)");
    $req->execute(['nom' => $nom , 'email'=> $email , 'password'=>$hash]);
    return $req;
}
function getUserByEmail($email){
    global $db;
    $req=$db->prepare("SELECT * FROM users WHERE email=:email " );
    $req->execute(["email"=>$email]);
    $user=$req->fetch(PDO::FETCH_OBJ);
return $user;
}

function getQuestions() {
    global $db;
    $query = $db->query("SELECT * FROM questions");
    $questions = $query->fetchAll(PDO::FETCH_ASSOC);
    return $questions;
}

function getUserEmailById($userId) {
    global $db;
    $stmt = $db->prepare("SELECT email FROM users WHERE id = :userId");
    $stmt->execute(["userId" => $userId]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($result) {
        return $result['email'];
    } else {
        return null; 
    }
}

function getUserNameById($userId) {
    global $db;
    $stmt = $db->prepare("SELECT nom FROM users WHERE id = :userId");
    $stmt->execute(["userId" => $userId]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($result) {
        return $result['nom'];
    } else {
        return null; 
    }
}

function getQuestionDetails($questionId) {
    global $db;
    
    $req = $db->prepare("SELECT * FROM questions WHERE id = :questionId");
    $req->execute(['questionId' => $questionId]);
    $result = $req->fetch(PDO::FETCH_ASSOC);

    return $result;
}


function getReponses($questionId) {
    global $db;
    $req = $db->prepare("
        SELECT r.*, u.nom as user_name, u.email as user_email
        FROM reponses r
        JOIN users u ON r.user_id = u.id
        WHERE r.question_id = :questionId
        ORDER BY r.date DESC
    ");
    $req->execute(["questionId" => $questionId]);
    return $req->fetchAll(PDO::FETCH_ASSOC);
}





?>
