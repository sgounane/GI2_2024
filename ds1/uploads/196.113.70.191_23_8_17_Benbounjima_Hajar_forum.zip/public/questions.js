document.addEventListener("DOMContentLoaded", function () {
  let questionsList = document.querySelector(".questions");
  let questionForm = document.getElementById("questionForm");

  function updateQuestions() {
    let req = new XMLHttpRequest();
    req.open("GET", "questions.php");
    req.onreadystatechange = function () {
      if (req.readyState == 4) {
        if (req.status == 200) {
          try {
            let response = JSON.parse(req.responseText);
            if (response && response.questions) {
              let questions = response.questions;
              displayQuestions(questions);
            } else {
              console.error("Invalid server response format:", response);
            }
          } catch (error) {
            console.error("Error parsing JSON response:", error);
          }
        } else {
          console.error(
            "Failed to fetch questions. Status code: " + req.status
          );
        }
      }
    };
    req.send();
  }

  function displayQuestions(questions) {
    questionsList.innerHTML = "";
    questions.forEach(function (question) {
      let listItem = document.createElement("div");
      listItem.className = "listeQ";
      listItem.innerHTML = `
                  <p class="date-nom-email">
                      <span class="date">${question.date}</span>
                      <span class="space"> </span>
                      <span class="nom">${
                        question.user ? question.user.nom : "Unknown"
                      }</span>
                      <span class="space"> </span>
                      <span class="email">${
                        question.user ? question.user.email : "Unknown"
                      }</span>
                  </p>
                  <div class="question">
                      ${question.question}
                      <a href="question.php?id=${question.id}">Réponses</a>
                  </div>
              `;
      questionsList.appendChild(listItem);
    });
  }

  questionForm.addEventListener("submit", function (event) {
    event.preventDefault();

    // Submit the form using AJAX
    let formData = new FormData(questionForm);
    let req = new XMLHttpRequest();
    req.open("POST", "home.php");
    req.onreadystatechange = function () {
      if (req.readyState == 4 && req.status == 200) {
        try {
          let response = JSON.parse(req.responseText);
          if (response && response.questions) {
            let questions = response.questions;
            displayQuestions(questions);
          } else {
            console.error("Invalid server response format:", response);
          }
        } catch (error) {
          console.error("Error parsing JSON response:", error);
        }
      } else if (req.readyState == 4) {
        console.error("Failed to submit question. Status code: " + req.status);
      }
    };
    req.send(formData);
  });

  setInterval(updateQuestions, 30000);

  updateQuestions();
});
