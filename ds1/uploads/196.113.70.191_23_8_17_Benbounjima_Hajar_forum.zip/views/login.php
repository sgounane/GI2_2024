<?php
include_once '../models/db.php';
session_start();

if (isset($_SESSION['user'])) {
    $user = $_SESSION['user'];
} else {
    $user = '';
} ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles/login.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <title>Login</title>
</head>
<body>
    <div class="container">
    <form action="../controllers/auth.php" method="POST" class="border mt-5 p-3 w-50 ml-auto mr-auto">
  <div class="form-group  ">
    <label for="email">Email :</label>
    <input type="email" class="form-control" name="email" aria-describedby="emailHelp"  required>

  </div>
  <div class="form-group">
    <label for="password">mot de passe:</label>
    <input type="password" class="form-control" name="password"  required>
  </div>
  <button type="submit" class="btn btn-primary" name="login">login</button>
  <p >do not have an account? <a href="register.php">register now</a></p>
  <div class="error-messages">
            <?php
            if (isset($_SESSION["errors"]) && !empty($_SESSION["errors"])) {
                foreach ($_SESSION["errors"] as $error) {
                    echo '<p style="color:red;">' . $error . '</p>';
                }
                unset($_SESSION["errors"]);
            }
            ?>
        </div>
</form>

</body>
</html>