<?php
include_once ("../models/db.php");
session_start();

$errors = array();

if (isset($_POST['register'])) {

    $name = $_POST['nom'];
    $name = filter_var($name, FILTER_SANITIZE_STRING);
    $email = $_POST['email']; 
    $email = filter_var($email, FILTER_SANITIZE_STRING);
    $pass = $_POST['password'];
    $pass = filter_var($pass, FILTER_SANITIZE_STRING);
    $cpass = $_POST['cpassword'];
    $cpass = filter_var($cpass, FILTER_SANITIZE_STRING);


            adduser($name, $email, $pass);

        }



?>
