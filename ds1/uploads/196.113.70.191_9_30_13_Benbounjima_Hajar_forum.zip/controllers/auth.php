<?php 
session_start();    
include_once("../models/db.php");
if (isset($_POST['login'])) {
    $email = $_POST['email']; 
    $email = filter_var($email, FILTER_SANITIZE_STRING);
    $pass = $_POST['password'];
    $pass = filter_var($pass, FILTER_SANITIZE_STRING);

    $users=getUserByEmail($_POST["email"]); 

            $pass=password_verify($_POST["password"],$users->password);
    if($pass){
        $_SESSION["user"]=["email"=>$users->email,"nom"=>$users->nom];
        header("location: ../views/home.php");
    }else{
        header("location: ../views/login.php"); 
        $_SESSION["errors"]="Email ou Mot de passe incorrecte !";
    }

}
else{
    header("location: ../views/login.php"); 
    $_SESSION["errors"]="Email ou Mot de passe incorrecte !";
}



