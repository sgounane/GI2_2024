<?php

function connect(){
    try {
        $db = new PDO('mysql:host=localhost;dbname=forum', 'root', '');
        return $db;
    } catch(PDOException $e){
        echo $e->getMessage();
        die();
    }
}
$db = connect();

function adduser($nom,$email,$password){
    global $db;
    $hash = password_hash($password, PASSWORD_BCRYPT);
    $req = $db->prepare("INSERT INTO users (nom,email,password) VALUES (:nom,:email,:password)");
    $req->execute(['nom' => $nom , 'email'=> $email , 'password'=>$hash]);
    return $req;
}
function getUserByEmail($email){
    global $db;
    $req=$db->prepare("SELECT * FROM users WHERE email=:email " );
    $req->execute(["email"=>$email]);
    $user=$req->fetch(PDO::FETCH_OBJ);
return $user;
}

function getQuestions() {
    global $db;
    $query = $db->query("SELECT * FROM questions");
    $questions = $query->fetchAll(PDO::FETCH_ASSOC);
    return $questions;
}

function getReponses($question_id) {
    global $db;
    $query = $db->prepare("SELECT * FROM reponses WHERE question_id = :question_id");
    $query->execute(['question_id' => $question_id]);
    $reponses = $query->fetchAll(PDO::FETCH_ASSOC);
    return $reponses;
}

?>
