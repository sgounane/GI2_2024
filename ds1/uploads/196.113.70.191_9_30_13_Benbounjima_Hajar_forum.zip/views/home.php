<?php
include_once('../models/db.php');
session_start();

// Get and display the list of questions
$questions = getQuestions();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
</head>
<body>
    <h1>Questions</h1>

    <?php foreach ($questions as $question) : ?>
        <div>
            <p>Date: <?php echo $question['date']; ?></p>
            <p>User: <?php echo $question['nom_user']; ?> (<?php echo $question['email_user']; ?>)</p>
            <p>Question: <?php echo $question['question']; ?></p>
            <p><a href="question.php?question_id=<?php echo $question['id']; ?>">Réponses</a></p>
        </div>
    <?php endforeach; ?>

    <?php if (isset($_SESSION['user_email'])) : ?>
        <a href="logout.php">Logout</a>

        <form action="post_question.php" method="POST">
            <label for="question">Your Question:</label>
            <textarea name="question" required></textarea>
            <button type="submit">Ask Question</button>
        </form>
    <?php else : ?>
        <a href="login.php">Login</a>
    <?php endif; ?>
</body>
</html>
