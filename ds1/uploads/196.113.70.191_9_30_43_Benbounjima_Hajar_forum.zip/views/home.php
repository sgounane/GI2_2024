<?php
include_once('../models/db.php');
session_start();
$questions = getQuestions();

usort($questions, function($a, $b) {
    return strtotime($b['date']) - strtotime($a['date']);
});

if (isset($_SESSION['user'])) {
    $user = $_SESSION['user'];
} else {
    $user = '';
} ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../styles/style.css">
    <title>Home</title>
</head>
<body>
    <div class="userQ">
    <?php if (isset($_SESSION['user'])) : ?>
        <form action="question.php" method="POST">
            <label for="question"></label>
            <input type="text" name="question" placeholder="Votre question ici..." required>
            <button type="submit" name="Envoyer">Envoyer</button>
        </form>
        <a href="logout.php" class="log">Logout</a>
    <?php else : ?>
        <a href="login.php" class="log">Login</a>
    <?php endif; ?>
    <div class="questions">
    <?php foreach ($questions as $question): ?>
        <div class="listeQ">
        <p class="date-nom-email">
            <span class="date"><?php echo $question['date']; ?></span>
            <span class="space"> </span>
            <span class="nom"><?php echo getUserNameById($question['user_id']); ?></span>
            <span class="space"> </span>
            <span class="email"><?php echo getUserEmailById($question['user_id']); ?></span>
        </p>
        <div class="question">
            <?php echo $question['question']; ?>
            <a href="question.php?id=<?php echo $question['id']; ?>">Réponses</a>
        </div>
        </div>
    <?php endforeach; ?>
    </div>            
</div>
</body>
</html>
