

<?php

include_once('../models/db.php');
session_start();

if (isset($_GET['id'])) {
    $questionId = $_GET['id'];
    $questionDetails = getQuestionDetails($questionId);
    $answers = getReponses($questionId);
} 

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['Envoyer']) && $_POST['Envoyer'] === "") {
    if (isset($_SESSION['user']['id'])) {
        $userId = $_SESSION['user']['id'];
        $questionId = $_POST['question_id'];
        $reponse = $_POST['reponse'];

        if ($userId !== null) {
            addReponse($questionId, $userId, $reponse);
        }
    }
}



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../styles/style.css">
    <title>Response</title>
</head>
<body>
    <div class="userQ">
        <?php if (isset($_SESSION['user'])) : ?>
            <form action="" method="POST">
    <label for="reponse"></label>
    <input type="text" name="reponse" placeholder="Votre réponse ici..." required>
    <input type="hidden" name="question_id" value="<?php echo $questionId; ?>">
    <button type="submit" name="Envoyer">Envoyer</button>
</form>

        <?php else : ?>
            <a href="login.php" class="log">Login</a>
        <?php endif; ?>

        <div class="question">
            <?php echo $questionDetails['question']; ?>
        </div>
        
        <a href="home.php" class="log" style="right:200px">Home</a>
        <a href="logout.php" class="log">Logout</a>

        <div class="answers">
            <?php if (!empty($answers)) : ?>
                <?php foreach ($answers as $answer) : ?>
                    <div class="listeQ">
                        <p class="user-details">
                            <span class="date"><?php echo $answer['date']; ?></span>
                            <span class="user-name"><?php echo $answer['user_name']; ?></span>
                            <span class="user-email"><?php echo $answer['user_email']; ?></span>
                        </p>
                        <p class="question"><?php echo $answer['reponse']; ?></p>
                    </div>
                <?php endforeach; ?>
            <?php else : ?>
                <p>No answers yet.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
